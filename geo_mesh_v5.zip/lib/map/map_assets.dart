import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// Готовит файлы, которые должны лежать на диске (нативный движок карты
/// не умеет читать из Flutter-assets): мировую карту и шрифты подписей.
class MapAssets {
  MapAssets._(
    this.root,
    this.worldPath,
    this.placesPath,
    this.worldSatPath,
    this.worldSatMaxZoom,
  );

  /// Папка с копиями (шрифты, стили).
  final String root;

  /// Путь к world_base_v2.mbtiles (векторная карта мира) на диске.
  final String worldPath;

  /// Встроенный спутниковый обзор мира (jpg-тайлы). null, если файл
  /// assets/maps/world_sat.mbtiles не положили в сборку.
  final String? worldSatPath;

  /// Максимальный зум встроенного спутника (из metadata файла).
  final int worldSatMaxZoom;

  /// Встроенный справочник городов мира (офлайн-поиск).
  final String placesPath;

  static const int _glyphVersion = 1;
  static const String _worldAsset = 'assets/maps/world_base.mbtiles';
  static const String _worldSatAsset = 'assets/maps/world_sat.mbtiles';

  /// Шаблон адреса шрифтов для style.json.
  String get glyphsUrl => 'file://$root/assets/glyphs/{fontstack}/{range}.pbf';

  static Future<MapAssets> prepare() async {
    final support = await getApplicationSupportDirectory();
    final root = p.join(support.path, 'mapdata');
    await Directory(root).create(recursive: true);

    // Старая растровая карта больше не нужна.
    try {
      await File(p.join(root, 'world_v1.mbtiles')).delete();
    } catch (_) {}

    final world = File(p.join(root, 'world_base_v2.mbtiles'));
    if (!await world.exists() || await world.length() == 0) {
      await _copyAsset(_worldAsset, world);
    }

    // Спутниковый обзор мира: необязательный файл, большой — копируем один раз.
    final satFile = File(p.join(root, 'world_sat_v1.mbtiles'));
    var hasSat = true;
    if (!await satFile.exists() || await satFile.length() == 0) {
      try {
        await _copyAsset(_worldSatAsset, satFile);
      } catch (_) {
        hasSat = false; // в сборке нет world_sat.mbtiles
      }
    }

    final places = File(p.join(root, 'places_v1.sqlite'));
    if (!await places.exists() || await places.length() == 0) {
      final data = await rootBundle.load('assets/maps/places.sqlite');
      final tmp = File('${places.path}.tmp');
      await tmp.writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        flush: true,
      );
      await tmp.rename(places.path);
    }

    final stamp = File(p.join(root, 'glyphs.version'));
    final upToDate =
        await stamp.exists() && await stamp.readAsString() == '$_glyphVersion';
    if (!upToDate) {
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      final glyphs = manifest.listAssets().where(
            (a) => a.startsWith('assets/glyphs/') && a.endsWith('.pbf'),
          );
      for (final asset in glyphs) {
        final data = await rootBundle.load(asset);
        final out = File(p.join(root, asset));
        await out.parent.create(recursive: true);
        await out.writeAsBytes(
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        );
      }
      await stamp.writeAsString('$_glyphVersion');
    }
    var satZoom = 6;
    if (hasSat) {
      try {
        final db = await openDatabase(satFile.path, readOnly: true);
        final rows = await db
            .rawQuery("SELECT value FROM metadata WHERE name = 'maxzoom'");
        await db.close();
        if (rows.isNotEmpty) {
          satZoom = int.tryParse('${rows.first['value']}') ?? satZoom;
        }
      } catch (_) {}
    }
    return MapAssets._(
      root,
      world.path,
      places.path,
      hasSat ? satFile.path : null,
      satZoom,
    );
  }

  /// Копирует asset на диск через временный файл (большие файлы не грузим
  /// целиком в память: rootBundle отдаёт ByteData, поэтому пишем одним куском,
  /// но атомарно).
  static Future<void> _copyAsset(String asset, File target) async {
    final data = await rootBundle.load(asset);
    final tmp = File('${target.path}.tmp');
    await tmp.writeAsBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      flush: true,
    );
    await tmp.rename(target.path);
  }
}
