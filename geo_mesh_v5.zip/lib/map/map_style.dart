import 'dart:convert';

import 'map_assets.dart';

enum MapTheme {
  color('Цветная'),
  light('Светлая'),
  dark('Тёмная'),
  satellite('Спутник (онлайн)');

  const MapTheme(this.title);
  final String title;
}

class _Palette {
  const _Palette({
    required this.land,
    required this.water,
    required this.park,
    required this.building,
    required this.extrusion,
    required this.roadMinor,
    required this.roadMajor,
    required this.roadMotorway,
    required this.casing,
    required this.label,
    required this.halo,
    required this.boundary,
    required this.urban,
  });

  final String land;
  final String water;
  final String park;
  final String building;
  final String extrusion;
  final String roadMinor;
  final String roadMajor;
  final String roadMotorway;
  final String casing;
  final String label;
  final String halo;
  final String boundary;
  final String urban;
}

const _color = _Palette(
  land: '#f2efe9',
  water: '#8fc3e6',
  park: '#b9dba0',
  building: '#d9cfc0',
  extrusion: '#cbbfae',
  roadMinor: '#ffffff',
  roadMajor: '#ffd978',
  roadMotorway: '#f58f3a',
  casing: '#a89f90',
  label: '#1f1f1f',
  halo: '#ffffff',
  boundary: '#a099a5',
  urban: '#e6d9c4',
);

const _light = _Palette(
  land: '#f1f1f1',
  water: '#b9cdd8',
  park: '#d3e0cb',
  building: '#e4e4e4',
  extrusion: '#dadada',
  roadMinor: '#ffffff',
  roadMajor: '#ffffff',
  roadMotorway: '#e6e6e6',
  casing: '#b0b0b0',
  label: '#111111',
  halo: '#ffffff',
  boundary: '#9a9a9a',
  urban: '#e3e3e3',
);

const _dark = _Palette(
  land: '#1d1d1d',
  water: '#0c2233',
  park: '#222a22',
  building: '#2a2a2e',
  extrusion: '#3a3a40',
  roadMinor: '#4a4a52',
  roadMajor: '#6b6b75',
  roadMotorway: '#9a9aa8',
  casing: '#111111',
  label: '#ececec',
  halo: '#1d1d1d',
  boundary: '#8a8a8a',
  urban: '#2a2a2e',
);

const _sat = _Palette(
  land: '#000000',
  water: '#000000',
  park: '#000000',
  building: '#ffffff',
  extrusion: '#ffffff',
  roadMinor: 'rgba(255,255,255,0.55)',
  roadMajor: 'rgba(255,255,255,0.8)',
  roadMotorway: 'rgba(255,215,120,0.9)',
  casing: 'rgba(0,0,0,0.0)',
  label: '#ffffff',
  halo: '#000000',
  boundary: 'rgba(255,255,255,0.6)',
  urban: 'rgba(0,0,0,0)',
);

/// Скачанный спутниковый пакет (.mbtiles с jpg-тайлами).
class SatLocal {
  const SatLocal(this.path, this.maxZoom);
  final String path;
  final int maxZoom;
}

/// Источники слоёв-наложений (заполняются из кода через setGeoJsonSource).
class OverlayIds {
  static const route = 'route';
  static const dest = 'dest';
  static const pick = 'pick';
  static const peers = 'peers';
  static const marks = 'marks';
}

class MapStyleBuilder {
  MapStyleBuilder._();

  static const _esri =
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
  static const _terrarium =
      'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png';

  /// Собирает style.json (строкой).
  /// [packPaths] — пути к установленным векторным .mbtiles (схема OpenMapTiles).
  static String build({
    required MapTheme theme,
    required MapAssets assets,
    required List<String> packPaths,
    List<SatLocal> satPacks = const [],
    bool buildings3d = true,
    bool relief = false,
  }) {
    final sat = theme == MapTheme.satellite;
    final pal = switch (theme) {
      MapTheme.color => _color,
      MapTheme.light => _light,
      MapTheme.dark => _dark,
      MapTheme.satellite => _sat,
    };

    final sources = <String, dynamic>{
      'world': {
        'type': 'vector',
        'url': 'mbtiles://${assets.worldPath}',
        'attribution': 'Natural Earth',
      },
      if (sat && assets.worldSatPath != null)
        'satw': {
          'type': 'raster',
          'tiles': ['mbtiles://${assets.worldSatPath}'],
          'tileSize': 256,
          'minzoom': 0,
          'maxzoom': assets.worldSatMaxZoom,
          'attribution': 'Sentinel-2 cloudless © EOX',
        },
      if (sat)
        'sat': {
          'type': 'raster',
          'tiles': [_esri],
          'tileSize': 256,
          'maxzoom': 19,
          'attribution': 'Esri, Maxar, Earthstar Geographics',
        },
      if (relief)
        'dem': {
          'type': 'raster-dem',
          'tiles': [_terrarium],
          'tileSize': 256,
          'maxzoom': 15,
          'encoding': 'terrarium',
          'attribution': 'Mapzen / AWS Terrain Tiles',
        },
      if (sat)
        for (var i = 0; i < satPacks.length; i++)
          'satl$i': {
            'type': 'raster',
            'tiles': ['mbtiles://${satPacks[i].path}'],
            'tileSize': 256,
            'minzoom': 0,
            'maxzoom': satPacks[i].maxZoom,
            'attribution': 'PNOA/IGN, Sentinel-2/EOX',
          },
      for (var i = 0; i < packPaths.length; i++)
        'pack$i': {
          'type': 'vector',
          'url': 'mbtiles://${packPaths[i]}',
          'attribution': '© OpenStreetMap contributors',
        },
      for (final id in [
        OverlayIds.route,
        OverlayIds.dest,
        OverlayIds.pick,
        OverlayIds.peers,
        OverlayIds.marks,
      ])
        id: {
          'type': 'geojson',
          'data': {'type': 'FeatureCollection', 'features': <dynamic>[]},
        },
    };

    final layers = <Map<String, dynamic>>[
      {
        'id': 'background',
        'type': 'background',
        // Фон — океан; сушу рисует слой world-land.
        'paint': {'background-color': sat ? '#000000' : pal.water},
      },
      if (!sat) ..._worldFills(pal),
      if (sat) ...[
        // Встроенный обзор мира внизу, онлайн-снимки над ним,
        // скачанные (офлайн) области поверх всего.
        if (assets.worldSatPath != null)
          {'id': 'satw', 'type': 'raster', 'source': 'satw'},
        {'id': 'sat', 'type': 'raster', 'source': 'sat'},
        for (var i = 0; i < satPacks.length; i++)
          {'id': 'satl$i', 'type': 'raster', 'source': 'satl$i'},
      ],
      ..._worldLines(pal, sat),
    ];

    // Нижние слои (заливки) всех пакетов.
    if (!sat) {
      for (var i = 0; i < packPaths.length; i++) {
        layers.addAll(_fills('pack$i', i, pal));
      }
    }
    if (relief && !sat) {
      layers.add({
        'id': 'hillshade',
        'type': 'hillshade',
        'source': 'dem',
        'paint': {
          'hillshade-exaggeration': theme == MapTheme.dark ? 0.35 : 0.5,
          'hillshade-shadow-color':
              theme == MapTheme.dark ? 'rgba(0,0,0,0.9)' : 'rgba(60,50,40,0.55)',
          'hillshade-highlight-color': theme == MapTheme.dark
              ? 'rgba(255,255,255,0.12)'
              : 'rgba(255,255,255,0.6)',
          'hillshade-accent-color': 'rgba(0,0,0,0.0)',
        },
      });
    }
    for (var i = 0; i < packPaths.length; i++) {
      layers.addAll(_roads('pack$i', i, pal, sat));
      layers.addAll(_buildings('pack$i', i, pal, sat, buildings3d));
      layers.addAll(_labels('pack$i', i, pal));
    }

    layers.addAll(_worldLabels(pal));
    layers.addAll(_overlays());

    return const JsonEncoder.withIndent(' ').convert({
      'version': 8,
      'name': 'geo_mesh_${theme.name}',
      'glyphs': assets.glyphsUrl,
      'sources': sources,
      'layers': layers,
    });
  }


  // ------------------------------------------------ встроенная карта мира
  // Источник 'world' — векторные тайлы Natural Earth 10m (до z8, дальше
  // растягиваются). Слои: land, lakes, rivers, urban, admin1, boundary,
  // roads, places, countries. Всё красится палитрой темы.

  static List<Map<String, dynamic>> _worldFills(_Palette p) => [
        {
          'id': 'world-land',
          'type': 'fill',
          'source': 'world',
          'source-layer': 'land',
          'paint': {'fill-color': p.land},
        },
        {
          'id': 'world-urban',
          'type': 'fill',
          'source': 'world',
          'source-layer': 'urban',
          'paint': {'fill-color': p.urban, 'fill-opacity': 0.9},
        },
        {
          'id': 'world-lakes',
          'type': 'fill',
          'source': 'world',
          'source-layer': 'lakes',
          'paint': {'fill-color': p.water},
        },
      ];

  static List<Map<String, dynamic>> _worldLines(_Palette p, bool sat) => [
        if (!sat)
          {
            'id': 'world-rivers',
            'type': 'line',
            'source': 'world',
            'source-layer': 'rivers',
            'minzoom': 2,
            'layout': {'line-cap': 'round', 'line-join': 'round'},
            'paint': {
              'line-color': p.water,
              'line-width': [
                'interpolate',
                ['linear'],
                ['zoom'],
                2,
                0.4,
                6,
                1.0,
                10,
                2.2,
              ],
            },
          },
        {
          'id': 'world-admin1',
          'type': 'line',
          'source': 'world',
          'source-layer': 'admin1',
          'minzoom': 3,
          'paint': {
            'line-color': p.boundary,
            'line-width': 0.7,
            'line-opacity': 0.7,
            'line-dasharray': [3, 2],
          },
        },
        {
          'id': 'world-boundary',
          'type': 'line',
          'source': 'world',
          'source-layer': 'boundary',
          'paint': {
            'line-color': p.boundary,
            'line-width': [
              'interpolate',
              ['linear'],
              ['zoom'],
              1,
              0.6,
              6,
              1.4,
              10,
              2,
            ],
          },
        },
        if (!sat) ...[
          {
            'id': 'world-road-casing',
            'type': 'line',
            'source': 'world',
            'source-layer': 'roads',
            'minzoom': 4,
            'maxzoom': 11,
            'layout': {'line-cap': 'round', 'line-join': 'round'},
            'paint': {
              'line-color': p.casing,
              'line-width': [
                'interpolate',
                ['linear'],
                ['zoom'],
                4,
                1.2,
                8,
                2.6,
                11,
                4.5,
              ],
            },
          },
          {
            'id': 'world-road',
            'type': 'line',
            'source': 'world',
            'source-layer': 'roads',
            'minzoom': 4,
            'maxzoom': 11,
            'layout': {'line-cap': 'round', 'line-join': 'round'},
            'paint': {
              'line-color': [
                'match',
                ['get', 'class'],
                'motorway',
                p.roadMotorway,
                p.roadMajor,
              ],
              'line-width': [
                'interpolate',
                ['linear'],
                ['zoom'],
                4,
                0.6,
                8,
                1.6,
                11,
                3,
              ],
            },
          },
        ],
      ];

  static const _nameRu = [
    'coalesce',
    ['get', 'name_ru'],
    ['get', 'name'],
  ];

  static List<Map<String, dynamic>> _worldLabels(_Palette p) => [
        {
          'id': 'world-country-name',
          'type': 'symbol',
          'source': 'world',
          'source-layer': 'countries',
          'maxzoom': 7,
          'layout': {
            'text-field': _nameRu,
            'text-font': ['Noto Sans Medium'],
            'text-size': [
              'interpolate',
              ['linear'],
              ['zoom'],
              1,
              10,
              5,
              14,
            ],
            'text-transform': 'uppercase',
            'text-letter-spacing': 0.12,
            'text-max-width': 7,
          },
          'paint': {
            'text-color': p.label,
            'text-opacity': 0.65,
            'text-halo-color': p.halo,
            'text-halo-width': 1.4,
          },
        },
        {
          'id': 'world-place-dot',
          'type': 'circle',
          'source': 'world',
          'source-layer': 'places',
          'minzoom': 3,
          'maxzoom': 11,
          'paint': {
            'circle-radius': [
              'case',
              ['==', ['get', 'cap'], 1],
              3.5,
              2.2,
            ],
            'circle-color': p.label,
            'circle-opacity': 0.8,
            'circle-stroke-color': p.halo,
            'circle-stroke-width': 1,
          },
        },
        {
          'id': 'world-place-name',
          'type': 'symbol',
          'source': 'world',
          'source-layer': 'places',
          'minzoom': 3,
          'maxzoom': 11,
          'layout': {
            'text-field': _nameRu,
            'text-font': ['Noto Sans Medium'],
            'text-size': [
              'interpolate',
              ['linear'],
              ['zoom'],
              3,
              10,
              8,
              13,
              10,
              15,
            ],
            'text-anchor': 'top',
            'text-offset': [0, 0.5],
            'text-max-width': 8,
            // Крупные города выигрывают при нехватке места.
            'symbol-sort-key': ['*', -1, ['coalesce', ['get', 'pop'], 0]],
          },
          'paint': _text(p, halo: 1.6),
        },
      ];

  static dynamic _w(num z10, num z14, num z18) => [
        'interpolate',
        ['exponential', 1.5],
        ['zoom'],
        8,
        z10 * 0.4,
        10,
        z10,
        14,
        z14,
        18,
        z18,
      ];

  static List<Map<String, dynamic>> _fills(String src, int i, _Palette p) => [
        {
          'id': 'landcover$i',
          'type': 'fill',
          'source': src,
          'source-layer': 'landcover',
          'filter': ['in', 'class', 'grass', 'wood'],
          'paint': {'fill-color': p.park, 'fill-opacity': 0.8},
        },
        {
          'id': 'park$i',
          'type': 'fill',
          'source': src,
          'source-layer': 'park',
          'paint': {'fill-color': p.park, 'fill-opacity': 0.8},
        },
        {
          'id': 'water$i',
          'type': 'fill',
          'source': src,
          'source-layer': 'water',
          'paint': {'fill-color': p.water},
        },
        {
          'id': 'waterway$i',
          'type': 'line',
          'source': src,
          'source-layer': 'waterway',
          'minzoom': 9,
          'paint': {'line-color': p.water, 'line-width': _w(0.6, 1.5, 4)},
        },
        {
          'id': 'boundary$i',
          'type': 'line',
          'source': src,
          'source-layer': 'boundary',
          'filter': ['<=', 'admin_level', 4],
          'paint': {
            'line-color': p.boundary,
            'line-width': 1,
            'line-dasharray': [3, 2],
          },
        },
      ];

  static List<Map<String, dynamic>> _roadPair(
    String src,
    int i,
    String name,
    List<String> classes,
    String color,
    String casing,
    List<num> w,
    int minzoom,
    bool sat,
  ) {
    return [
      if (!sat)
        {
          'id': 'road-$name-casing$i',
          'type': 'line',
          'source': src,
          'source-layer': 'transportation',
          'minzoom': minzoom,
          'filter': ['in', 'class', ...classes],
          'layout': {'line-cap': 'round', 'line-join': 'round'},
          'paint': {
            'line-color': casing,
            'line-width': _w(w[0] + 1, w[1] + 1.5, w[2] + 2),
          },
        },
      {
        'id': 'road-$name$i',
        'type': 'line',
        'source': src,
        'source-layer': 'transportation',
        'minzoom': minzoom,
        'filter': ['in', 'class', ...classes],
        'layout': {'line-cap': 'round', 'line-join': 'round'},
        'paint': {'line-color': color, 'line-width': _w(w[0], w[1], w[2])},
      },
    ];
  }

  static List<Map<String, dynamic>> _roads(
    String src,
    int i,
    _Palette p,
    bool sat,
  ) =>
      [
        ..._roadPair(src, i, 'minor', ['minor', 'service'], p.roadMinor,
            p.casing, [0.6, 3.2, 11], 12, sat),
        ..._roadPair(src, i, 'major', ['tertiary', 'secondary', 'primary'],
            p.roadMajor, p.casing, [1.0, 4.5, 16], 8, sat),
        ..._roadPair(src, i, 'motorway', ['motorway', 'trunk'],
            p.roadMotorway, p.casing, [1.2, 4, 16], 5, sat),
        {
          'id': 'road-path$i',
          'type': 'line',
          'source': src,
          'source-layer': 'transportation',
          'minzoom': 14,
          'filter': ['in', 'class', 'path', 'track', 'pedestrian'],
          'paint': {
            'line-color': p.label,
            'line-width': 1,
            'line-opacity': 0.55,
            'line-dasharray': [2, 2],
          },
        },
        {
          'id': 'rail$i',
          'type': 'line',
          'source': src,
          'source-layer': 'transportation',
          'minzoom': 11,
          'filter': ['==', 'class', 'rail'],
          'paint': {
            'line-color': p.boundary,
            'line-width': 1,
            'line-dasharray': [4, 3],
          },
        },
      ];

  static List<Map<String, dynamic>> _buildings(
    String src,
    int i,
    _Palette p,
    bool sat,
    bool extrude,
  ) {
    final height = ['coalesce', ['get', 'render_height'], 6];
    final base = ['coalesce', ['get', 'render_min_height'], 0];
    return [
      if (!extrude && !sat)
        {
          'id': 'building-flat$i',
          'type': 'fill',
          'source': src,
          'source-layer': 'building',
          'minzoom': 13,
          'paint': {'fill-color': p.building},
        },
      if (extrude)
        {
          'id': 'building-3d$i',
          'type': 'fill-extrusion',
          'source': src,
          'source-layer': 'building',
          'minzoom': 14,
          'paint': {
            'fill-extrusion-color': p.extrusion,
            'fill-extrusion-height': height,
            'fill-extrusion-base': base,
            'fill-extrusion-opacity': sat ? 0.35 : 0.9,
            'fill-extrusion-vertical-gradient': true,
          },
        },
    ];
  }

  static Map<String, dynamic> _text(_Palette p, {double halo = 1.4}) => {
        'text-color': p.label,
        'text-halo-color': p.halo,
        'text-halo-width': halo,
      };

  static List<Map<String, dynamic>> _labels(String src, int i, _Palette p) => [
        {
          'id': 'water-name$i',
          'type': 'symbol',
          'source': src,
          'source-layer': 'water_name',
          'layout': {
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Regular'],
            'text-size': 12,
          },
          'paint': _text(p),
        },
        {
          'id': 'road-name$i',
          'type': 'symbol',
          'source': src,
          'source-layer': 'transportation_name',
          'minzoom': 13,
          'layout': {
            'symbol-placement': 'line',
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Regular'],
            'text-size': 11,
          },
          'paint': _text(p),
        },
        {
          'id': 'poi-dot$i',
          'type': 'circle',
          'source': src,
          'source-layer': 'poi',
          'minzoom': 16,
          'paint': {
            'circle-radius': 3,
            'circle-color': p.label,
            'circle-opacity': 0.6,
          },
        },
        {
          'id': 'poi-name$i',
          'type': 'symbol',
          'source': src,
          'source-layer': 'poi',
          'minzoom': 16,
          'layout': {
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Regular'],
            'text-size': 11,
            'text-offset': [0, 0.9],
            'text-anchor': 'top',
            'text-optional': true,
          },
          'paint': _text(p),
        },
        {
          'id': 'housenumber$i',
          'type': 'symbol',
          'source': src,
          'source-layer': 'housenumber',
          'minzoom': 17,
          'layout': {
            'text-field': ['get', 'housenumber'],
            'text-font': ['Noto Sans Regular'],
            'text-size': 10,
          },
          'paint': _text(p, halo: 1),
        },
        {
          'id': 'place$i',
          'type': 'symbol',
          'source': src,
          'source-layer': 'place',
          'filter': [
            'in',
            'class',
            'city',
            'town',
            'village',
            'suburb',
            'neighbourhood',
            'hamlet',
          ],
          'layout': {
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Medium'],
            'text-size': [
              'match',
              ['get', 'class'],
              'city',
              17,
              'town',
              15,
              'village',
              13,
              'suburb',
              12,
              11,
            ],
          },
          'paint': _text(p, halo: 1.6),
        },
      ];

  static List<Map<String, dynamic>> _overlays() => [
        {
          'id': 'route-casing',
          'type': 'line',
          'source': OverlayIds.route,
          'layout': {'line-cap': 'round', 'line-join': 'round'},
          'paint': {'line-color': '#ffffff', 'line-width': 9},
        },
        {
          'id': 'route-line',
          'type': 'line',
          'source': OverlayIds.route,
          'layout': {'line-cap': 'round', 'line-join': 'round'},
          'paint': {'line-color': '#1e88e5', 'line-width': 6},
        },
        {
          'id': 'pick-dot',
          'type': 'circle',
          'source': OverlayIds.pick,
          'paint': {
            'circle-radius': 8,
            'circle-color': '#e53935',
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 3,
          },
        },
        {
          'id': 'dest-dot',
          'type': 'circle',
          'source': OverlayIds.dest,
          'paint': {
            'circle-radius': 9,
            'circle-color': '#43a047',
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 3,
          },
        },
        {
          'id': 'marks-dot',
          'type': 'circle',
          'source': OverlayIds.marks,
          'paint': {
            'circle-radius': 9,
            'circle-color': '#ffb300',
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 3,
          },
        },
        {
          'id': 'marks-name',
          'type': 'symbol',
          'source': OverlayIds.marks,
          'layout': {
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Medium'],
            'text-size': 13,
            'text-offset': [0, 1.2],
            'text-anchor': 'top',
            'text-optional': true,
          },
          'paint': {
            'text-color': '#111111',
            'text-halo-color': '#ffffff',
            'text-halo-width': 1.8,
          },
        },
        {
          'id': 'peers-dot',
          'type': 'circle',
          'source': OverlayIds.peers,
          'paint': {
            'circle-radius': 8,
            'circle-color': '#fb8c00',
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 3,
          },
        },
        {
          'id': 'peers-name',
          'type': 'symbol',
          'source': OverlayIds.peers,
          'layout': {
            'text-field': ['get', 'name'],
            'text-font': ['Noto Sans Medium'],
            'text-size': 12,
            'text-offset': [0, 1.2],
            'text-anchor': 'top',
          },
          'paint': {
            'text-color': '#111111',
            'text-halo-color': '#ffffff',
            'text-halo-width': 1.6,
          },
        },
      ];
}
