import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Анимация входа: логотип рисуется, затем название плавно появляется.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, required this.onDone, this.animate = true});
  final VoidCallback onDone;
  final bool animate;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  );

  @override
  void initState() {
    super.initState();
    if (!widget.animate) {
      WidgetsBinding.instance.addPostFrameCallback((_) => widget.onDone());
      return;
    }
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1220),
      body: Center(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final t = _c.value;
            final logo = Curves.easeOutCubic.transform((t / 0.6).clamp(0, 1));
            final text = Curves.easeOut.transform(((t - 0.45) / 0.4).clamp(0, 1));
            final out = 1 - Curves.easeIn.transform(((t - 0.88) / 0.12).clamp(0, 1));
            return Opacity(
              opacity: out,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Transform.scale(
                    scale: 0.7 + 0.3 * logo,
                    child: CustomPaint(
                      size: const Size(132, 132),
                      painter: LogoPainter(progress: logo),
                    ),
                  ),
                  const SizedBox(height: 28),
                  Opacity(
                    opacity: text,
                    child: Transform.translate(
                      offset: Offset(0, 12 * (1 - text)),
                      child: const Column(
                        children: [
                          Text(
                            'GeoMesh',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 4,
                            ),
                          ),
                          SizedBox(height: 6),
                          Text(
                            'Карта без интернета',
                            style: TextStyle(color: Color(0xFF8FA3C7), fontSize: 14, letterSpacing: 1.5),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Логотип: кольца-сигнал вокруг метки. Тот же рисунок использован для иконки.
class LogoPainter extends CustomPainter {
  LogoPainter({this.progress = 1});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF3D5AFE), Color(0xFF00BFA5)],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(r * 0.46)),
      bg,
    );
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withValues(alpha: 0.55)
      ..strokeWidth = r * 0.07;
    for (var i = 0; i < 2; i++) {
      final rad = r * (0.5 + 0.22 * i);
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: rad),
        -math.pi * 0.85,
        math.pi * 1.7 * progress,
        false,
        ring,
      );
    }
    final pin = Path()
      ..moveTo(c.dx, c.dy + r * 0.34)
      ..cubicTo(c.dx - r * 0.34, c.dy - r * 0.02, c.dx - r * 0.24, c.dy - r * 0.36, c.dx, c.dy - r * 0.36)
      ..cubicTo(c.dx + r * 0.24, c.dy - r * 0.36, c.dx + r * 0.34, c.dy - r * 0.02, c.dx, c.dy + r * 0.34)
      ..close();
    canvas.drawPath(pin, Paint()..color = Colors.white.withValues(alpha: progress));
    canvas.drawCircle(
      c.translate(0, -r * 0.12),
      r * 0.1,
      Paint()..color = const Color(0xFF3D5AFE),
    );
  }

  @override
  bool shouldRepaint(LogoPainter old) => old.progress != progress;
}
