import 'package:latlong2/latlong.dart';

import '../geo/geohash.dart';
import '../settings/app_settings.dart';

String _dms(double v, String pos, String neg) {
  final h = v >= 0 ? pos : neg;
  v = v.abs();
  final d = v.floor();
  final m = ((v - d) * 60).floor();
  final s = ((v - d) * 60 - m) * 60;
  return '$d°$m′${s.toStringAsFixed(1)}″$h';
}

String formatCoord(LatLng p, CoordFormat f) {
  switch (f) {
    case CoordFormat.decimal:
      return '${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)}';
    case CoordFormat.dms:
      return '${_dms(p.latitude, 'N', 'S')} ${_dms(p.longitude, 'E', 'W')}';
    case CoordFormat.geohash:
      return Geohash.encode(p.latitude, p.longitude, precision: 9);
  }
}
