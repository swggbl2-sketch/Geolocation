import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

import 'geo_message.dart';
import 'mesh_transport.dart';
import 'peer_markers.dart';

/// Связывает карту и mesh-транспорт:
///  * исходящие: LatLng -> `GEO:<hash>` -> transport.sendText
///  * входящие: `GEO:<hash>` -> декодирование -> маркер на карте
class GeoSharingService {
  GeoSharingService({
    required this.transport,
    required this.markers,
    this.precision = 9,
    this.minSendInterval = const Duration(seconds: 30),
  }) {
    _sub = transport.incoming.listen(handleIncoming);
  }

  final MeshTransport transport;
  final PeerMarkersController markers;
  final int precision;

  /// Защита эфира: LoRa имеет жёсткие ограничения по duty cycle.
  final Duration minSendInterval;

  late final StreamSubscription<MeshTextMessage> _sub;
  DateTime? _lastSent;

  /// Отправить позицию. Возвращает false, если сработал троттлинг.
  Future<bool> sendPosition(LatLng position, {bool force = false}) async {
    final now = DateTime.now();
    final last = _lastSent;
    if (!force && last != null && now.difference(last) < minSendInterval) {
      return false;
    }
    await transport.sendText(
      GeoMessage.buildFromLatLng(position, precision: precision),
    );
    _lastSent = now;
    return true;
  }

  /// Обработчик входящих. Не-GEO сообщения игнорируются (это обычный чат).
  void handleIncoming(MeshTextMessage msg) {
    final geo = GeoMessage.tryParse(msg.text);
    if (geo == null) {
      if (msg.text.trimLeft().startsWith(GeoMessage.prefix)) {
        debugPrint('GEO: повреждённый хеш от ${msg.fromNode}: "${msg.text}"');
      }
      return;
    }
    markers.upsert(
      PeerMarker(
        nodeId: msg.fromNode,
        position: geo.position,
        geohash: geo.geohash,
        accuracyMeters: geo.errorMeters,
        receivedAt: msg.receivedAt,
      ),
    );
  }

  Future<void> dispose() => _sub.cancel();
}
