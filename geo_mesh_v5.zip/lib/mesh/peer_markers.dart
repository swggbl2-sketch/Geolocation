import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

class PeerMarker {
  const PeerMarker({
    required this.nodeId,
    required this.position,
    required this.geohash,
    required this.accuracyMeters,
    required this.receivedAt,
  });

  final String nodeId;
  final LatLng position;
  final String geohash;
  final double accuracyMeters;
  final DateTime receivedAt;
}

/// Хранит последнюю известную позицию каждого узла. Карта слушает изменения.
class PeerMarkersController extends ChangeNotifier {
  final Map<String, PeerMarker> _peers = {};

  List<PeerMarker> get peers => List.unmodifiable(_peers.values);

  void upsert(PeerMarker marker) {
    _peers[marker.nodeId] = marker;
    notifyListeners();
  }

  void removeStale(Duration maxAge) {
    final limit = DateTime.now().subtract(maxAge);
    final before = _peers.length;
    _peers.removeWhere((_, m) => m.receivedAt.isBefore(limit));
    if (_peers.length != before) notifyListeners();
  }
}
