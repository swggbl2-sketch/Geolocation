import 'dart:async';

/// Входящее текстовое сообщение из mesh-сети.
class MeshTextMessage {
  const MeshTextMessage({
    required this.fromNode,
    required this.text,
    required this.receivedAt,
  });

  /// Идентификатор узла-отправителя (в Meshtastic это node id, например "!a1b2c3d4").
  final String fromNode;
  final String text;
  final DateTime receivedAt;
}

/// Абстракция над вашим кастомным мессенджером (Bluetooth -> LoRa-модем).
/// Реализуйте этот интерфейс поверх своего BLE-кода.
abstract class MeshTransport {
  /// Текстовые сообщения, пришедшие из сети.
  Stream<MeshTextMessage> get incoming;

  /// Отправка текста в сеть через модем.
  Future<void> sendText(String text);
}

/// Заглушка для тестов без железа: отправленное не уходит никуда,
/// а входящие можно имитировать вручную.
class LoopbackMeshTransport implements MeshTransport {
  final _controller = StreamController<MeshTextMessage>.broadcast();
  final List<String> sent = [];

  @override
  Stream<MeshTextMessage> get incoming => _controller.stream;

  @override
  Future<void> sendText(String text) async {
    sent.add(text);
  }

  void simulateIncoming(String fromNode, String text) {
    _controller.add(
      MeshTextMessage(fromNode: fromNode, text: text, receivedAt: DateTime.now()),
    );
  }

  Future<void> dispose() => _controller.close();
}
