import 'package:latlong2/latlong.dart';

import '../geo/geohash.dart';

/// Формат сообщения: `GEO:<geohash>`, например `GEO:ezzp3k8dq`.
class GeoMessage {
  const GeoMessage._(this.geohash, this.cell);

  static const String prefix = 'GEO:';

  final String geohash;
  final GeohashCell cell;

  LatLng get position => cell.center;
  double get errorMeters => cell.errorMeters;

  /// Сформировать текст для отправки через LoRa.
  static String build(double lat, double lon, {int precision = 9}) {
    return '$prefix${Geohash.encode(lat, lon, precision: precision)}';
  }

  static String buildFromLatLng(LatLng p, {int precision = 9}) =>
      build(p.latitude, p.longitude, precision: precision);

  /// Разобрать входящую строку. Возвращает null, если это не GEO-сообщение
  /// или хеш повреждён (LoRa может терять/портить пакеты).
  static GeoMessage? tryParse(String text) {
    final t = text.trim();
    if (!t.startsWith(prefix)) return null;
    final hash = t.substring(prefix.length).trim().toLowerCase();
    if (!Geohash.isValid(hash)) return null;
    return GeoMessage._(hash, Geohash.decodeCell(hash));
  }
}
