import 'dart:math' as math;

import 'package:latlong2/latlong.dart';

/// Ячейка геохеша: центр и половина её размера (±погрешность).
class GeohashCell {
  const GeohashCell({
    required this.center,
    required this.latError,
    required this.lonError,
    required this.precision,
  });

  final LatLng center;

  /// Половина высоты ячейки, градусы.
  final double latError;

  /// Половина ширины ячейки, градусы.
  final double lonError;

  final int precision;

  /// Грубая оценка максимального отклонения центра от истинной точки, метры.
  double get errorMeters {
    const metersPerDegree = 111320.0;
    final latM = latError * metersPerDegree;
    final lonM =
        lonError * metersPerDegree * math.cos(center.latitude * math.pi / 180);
    return math.max(latM, lonM);
  }
}

/// Кодирование/декодирование Geohash (стандартный алфавит base32).
///
/// Размер ячейки на широте Аликанте (~38°):
///   7 симв. ≈ 150 × 120 м
///   8 симв. ≈  38 ×  30 м
///   9 симв. ≈ 4.8 × 3.8 м   <- рекомендуемое значение
///  10 симв. ≈ 1.2 × 0.9 м
class Geohash {
  Geohash._();

  static const String _alphabet = '0123456789bcdefghjkmnpqrstuvwxyz';
  static const int maxPrecision = 12;

  static final Map<String, int> _index = {
    for (var i = 0; i < _alphabet.length; i++) _alphabet[i]: i,
  };

  /// lat/lon -> геохеш заданной длины (по умолчанию 9 символов).
  static String encode(double lat, double lon, {int precision = 9}) {
    if (precision < 1 || precision > maxPrecision) {
      throw RangeError.range(precision, 1, maxPrecision, 'precision');
    }
    if (lat.isNaN || lon.isNaN || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      throw RangeError('Недопустимые координаты: lat=$lat, lon=$lon');
    }

    var latMin = -90.0, latMax = 90.0;
    var lonMin = -180.0, lonMax = 180.0;
    final out = StringBuffer();
    var isLon = true; // биты чередуются, начиная с долготы
    var bitCount = 0;
    var value = 0;

    while (out.length < precision) {
      if (isLon) {
        final mid = (lonMin + lonMax) / 2;
        if (lon >= mid) {
          value = (value << 1) | 1;
          lonMin = mid;
        } else {
          value = value << 1;
          lonMax = mid;
        }
      } else {
        final mid = (latMin + latMax) / 2;
        if (lat >= mid) {
          value = (value << 1) | 1;
          latMin = mid;
        } else {
          value = value << 1;
          latMax = mid;
        }
      }
      isLon = !isLon;
      if (++bitCount == 5) {
        out.write(_alphabet[value]);
        bitCount = 0;
        value = 0;
      }
    }
    return out.toString();
  }

  /// Проверка строки без исключений.
  static bool isValid(String hash) {
    final h = hash.trim().toLowerCase();
    if (h.isEmpty || h.length > maxPrecision) return false;
    for (var i = 0; i < h.length; i++) {
      if (!_index.containsKey(h[i])) return false;
    }
    return true;
  }

  /// геохеш -> ячейка (центр + погрешность). Бросает FormatException.
  static GeohashCell decodeCell(String hash) {
    final h = hash.trim().toLowerCase();
    if (h.isEmpty || h.length > maxPrecision) {
      throw FormatException('Длина геохеша должна быть 1..$maxPrecision', hash);
    }

    var latMin = -90.0, latMax = 90.0;
    var lonMin = -180.0, lonMax = 180.0;
    var isLon = true;

    for (var i = 0; i < h.length; i++) {
      final v = _index[h[i]];
      if (v == null) {
        throw FormatException('Недопустимый символ "${h[i]}" в геохеше', hash);
      }
      for (var mask = 16; mask > 0; mask >>= 1) {
        final bit = (v & mask) != 0;
        if (isLon) {
          final mid = (lonMin + lonMax) / 2;
          if (bit) {
            lonMin = mid;
          } else {
            lonMax = mid;
          }
        } else {
          final mid = (latMin + latMax) / 2;
          if (bit) {
            latMin = mid;
          } else {
            latMax = mid;
          }
        }
        isLon = !isLon;
      }
    }

    return GeohashCell(
      center: LatLng((latMin + latMax) / 2, (lonMin + lonMax) / 2),
      latError: (latMax - latMin) / 2,
      lonError: (lonMax - lonMin) / 2,
      precision: h.length,
    );
  }

  /// геохеш -> координаты центра ячейки (для маркера на карте).
  static LatLng decode(String hash) => decodeCell(hash).center;
}
