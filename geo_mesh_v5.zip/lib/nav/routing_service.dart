import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:latlong2/latlong.dart';

enum TravelMode {
  foot('Пешком', 'routed-foot', 1.4),
  car('На машине', 'routed-car', 11.0);

  const TravelMode(this.title, this.osrmPath, this.fallbackSpeedMs);
  final String title;
  final String osrmPath;

  /// Скорость для оценки времени, когда маршрут не построен по дорогам.
  final double fallbackSpeedMs;
}

class RouteStep {
  const RouteStep({
    required this.text,
    required this.distanceM,
    required this.pointIndex,
  });

  final String text;
  final double distanceM;

  /// Индекс вершины маршрута, где выполняется манёвр.
  final int pointIndex;
}

class RouteResult {
  const RouteResult({
    required this.points,
    required this.distanceM,
    required this.durationS,
    required this.steps,
    required this.byRoads,
  });

  final List<LatLng> points;
  final double distanceM;
  final double durationS;
  final List<RouteStep> steps;

  /// false — сети нет, показана прямая линия до цели.
  final bool byRoads;
}

class RoutingService {
  static const _userAgent = 'GeoMesh/0.2 (offline map app)';
  static const _dist = Distance();

  Future<RouteResult> route(LatLng from, LatLng to, TravelMode mode) async {
    try {
      final r = await _osrm(from, to, mode);
      if (r != null) return r;
    } catch (_) {
      // нет сети или сервис недоступен — переходим к прямой линии
    }
    return straight(from, to, mode);
  }

  /// Запасной вариант без сети: прямая линия, расстояние и направление.
  static RouteResult straight(LatLng from, LatLng to, TravelMode mode) {
    final d = _dist.as(LengthUnit.Meter, from, to);
    return RouteResult(
      points: [from, to],
      distanceM: d,
      durationS: d / mode.fallbackSpeedMs,
      steps: [
        RouteStep(text: 'Двигайтесь к цели по прямой', distanceM: d, pointIndex: 0),
        RouteStep(text: 'Вы на месте', distanceM: 0, pointIndex: 1),
      ],
      byRoads: false,
    );
  }

  Future<RouteResult?> _osrm(LatLng a, LatLng b, TravelMode mode) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    try {
      final coords = '${a.longitude},${a.latitude};${b.longitude},${b.latitude}';
      final uri = Uri.parse(
        'https://routing.openstreetmap.de/${mode.osrmPath}/route/v1/driving/$coords'
        '?overview=full&geometries=geojson&steps=true',
      );
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.userAgentHeader, _userAgent);
      final resp = await req.close().timeout(const Duration(seconds: 10));
      if (resp.statusCode != 200) {
        await resp.drain<void>();
        return null;
      }
      final json =
          jsonDecode(await resp.transform(utf8.decoder).join()) as Map<String, dynamic>;
      final routes = json['routes'] as List?;
      if (json['code'] != 'Ok' || routes == null || routes.isEmpty) return null;
      final r = routes.first as Map<String, dynamic>;

      final pts = <LatLng>[
        for (final c in (r['geometry']['coordinates'] as List))
          LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()),
      ];
      if (pts.length < 2) return null;

      final steps = <RouteStep>[];
      for (final leg in (r['legs'] as List)) {
        for (final s in (leg['steps'] as List)) {
          final m = s['maneuver'] as Map<String, dynamic>;
          final loc = m['location'] as List;
          final at = LatLng((loc[1] as num).toDouble(), (loc[0] as num).toDouble());
          steps.add(
            RouteStep(
              text: _instruction(
                '${m['type']}',
                m['modifier'] as String?,
                '${s['name'] ?? ''}',
                (m['exit'] as num?)?.toInt(),
              ),
              distanceM: (s['distance'] as num).toDouble(),
              pointIndex: _nearestIndex(pts, at),
            ),
          );
        }
      }
      return RouteResult(
        points: pts,
        distanceM: (r['distance'] as num).toDouble(),
        durationS: (r['duration'] as num).toDouble(),
        steps: steps,
        byRoads: true,
      );
    } finally {
      client.close(force: true);
    }
  }

  static int _nearestIndex(List<LatLng> pts, LatLng at) {
    var best = 0;
    var bestD = double.infinity;
    for (var i = 0; i < pts.length; i++) {
      final d = _dist.as(LengthUnit.Meter, pts[i], at);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return best;
  }

  static String _instruction(String type, String? modifier, String street, int? exit) {
    final on = street.isEmpty ? '' : ' на $street';
    final dir = switch (modifier) {
      'left' => 'налево',
      'right' => 'направо',
      'slight left' => 'левее',
      'slight right' => 'правее',
      'sharp left' => 'резко налево',
      'sharp right' => 'резко направо',
      'uturn' => 'развернитесь',
      _ => 'прямо',
    };
    switch (type) {
      case 'depart':
        return 'Начните движение$on';
      case 'arrive':
        return 'Вы прибыли в точку назначения';
      case 'roundabout':
      case 'rotary':
        return exit == null
            ? 'На круговом движении продолжайте$on'
            : 'На круговом движении съезд №$exit$on';
      case 'turn':
      case 'end of road':
      case 'fork':
      case 'on ramp':
      case 'off ramp':
        return modifier == 'uturn' ? 'Развернитесь' : 'Поверните $dir$on';
      default:
        return 'Продолжайте $dir$on';
    }
  }
}
