import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

import 'routing_service.dart';

/// Состояние навигации к точке. Получает позиции, считает остаток пути,
/// следующий манёвр и признак схода с маршрута.
class NavigationController extends ChangeNotifier {
  static const _dist = Distance();

  LatLng? destination;
  String destinationName = '';
  TravelMode mode = TravelMode.foot;
  RouteResult? route;

  bool get active => destination != null && route != null;

  LatLng? position;
  int _idx = 0;
  int _offCount = 0;

  /// Осталось по маршруту, метры.
  double remainingM = 0;

  /// Оценка оставшегося времени, секунды.
  double remainingS = 0;

  /// Расстояние от маршрута до вас, метры.
  double offRouteM = 0;

  RouteStep? nextStep;
  double distToNextStepM = 0;

  /// Азимут на цель (0 — север), градусы.
  double bearingToTarget = 0;

  /// Вызывается, когда вы ушли с маршрута и стоит построить новый.
  VoidCallback? onNeedReroute;

  bool arrived = false;

  void start({
    required LatLng destination,
    required String name,
    required TravelMode mode,
    required RouteResult route,
  }) {
    this.destination = destination;
    destinationName = name;
    this.mode = mode;
    this.route = route;
    _idx = 0;
    _offCount = 0;
    arrived = false;
    remainingM = route.distanceM;
    remainingS = route.durationS;
    _recompute();
    notifyListeners();
  }

  void replaceRoute(RouteResult r) {
    route = r;
    _idx = 0;
    _offCount = 0;
    remainingM = r.distanceM;
    remainingS = r.durationS;
    _recompute();
    notifyListeners();
  }

  void stop() {
    destination = null;
    route = null;
    arrived = false;
    notifyListeners();
  }

  void updatePosition(LatLng p) {
    position = p;
    if (!active) return;
    _recompute();
    notifyListeners();
  }

  void _recompute() {
    final r = route;
    final pos = position;
    final dest = destination;
    if (r == null || dest == null) return;
    if (pos == null) return;

    bearingToTarget = _dist.bearing(pos, dest);

    // Ближайшая вершина маршрута, ищем вперёд от прошлой (маршрут не «откатывается»).
    final pts = r.points;
    var best = _idx;
    var bestD = double.infinity;
    final end = math.min(pts.length, _idx + 400);
    for (var i = _idx; i < end; i++) {
      final d = _dist.as(LengthUnit.Meter, pos, pts[i]);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    _idx = best;
    offRouteM = bestD;

    var rest = 0.0;
    for (var i = _idx; i < pts.length - 1; i++) {
      rest += _dist.as(LengthUnit.Meter, pts[i], pts[i + 1]);
    }
    remainingM = rest + (_idx < pts.length ? bestD : 0);
    remainingS = r.distanceM > 0 ? r.durationS * (remainingM / r.distanceM) : 0;

    // Следующий манёвр — первый, который ещё впереди.
    nextStep = null;
    for (final s in r.steps) {
      if (s.pointIndex > _idx) {
        nextStep = s;
        var d = _dist.as(LengthUnit.Meter, pos, pts[_idx]);
        for (var i = _idx; i < s.pointIndex && i < pts.length - 1; i++) {
          d += _dist.as(LengthUnit.Meter, pts[i], pts[i + 1]);
        }
        distToNextStepM = d;
        break;
      }
    }

    final toDest = _dist.as(LengthUnit.Meter, pos, dest);
    if (toDest < (mode == TravelMode.foot ? 15 : 30)) {
      arrived = true;
      return;
    }

    final limit = mode == TravelMode.foot ? 40.0 : 60.0;
    if (r.byRoads && bestD > limit) {
      if (++_offCount >= 3) {
        _offCount = 0;
        onNeedReroute?.call();
      }
    } else {
      _offCount = 0;
    }
  }

  static bool metric = true;

  static String formatDistance(double m) {
    if (!metric) {
      final ft = m * 3.28084;
      if (ft < 1000) return '${(ft / 10).round() * 10} фт';
      final mi = m / 1609.344;
      return '${mi.toStringAsFixed(mi < 10 ? 1 : 0)} ми';
    }
    if (m < 950) return '${(m / 10).round() * 10} м';
    return '${(m / 1000).toStringAsFixed(m < 10000 ? 1 : 0)} км';
  }

  static String formatDuration(double s) {
    final min = (s / 60).round();
    if (min < 1) return '< 1 мин';
    if (min < 60) return '$min мин';
    return '${min ~/ 60} ч ${min % 60} мин';
  }
}
