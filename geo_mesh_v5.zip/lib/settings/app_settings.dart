import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../map/map_style.dart';

enum CoordFormat {
  decimal('Десятичные', '38.34520, -0.48100'),
  dms('Градусы-минуты-секунды', '38°20′42.7″N 0°28′51.6″W'),
  geohash('Геохеш', 'ezjmgtw');

  const CoordFormat(this.title, this.example);
  final String title;
  final String example;
}

/// Все пользовательские настройки. Сохраняются сразу при изменении.
class AppSettings extends ChangeNotifier {
  AppSettings._(this._p) {
    _read();
  }

  final SharedPreferences _p;

  static Future<AppSettings> open() async =>
      AppSettings._(await SharedPreferences.getInstance());

  // значения по умолчанию
  MapTheme mapTheme = MapTheme.color;
  bool buildings3d = true;
  bool relief = false;
  ThemeMode appTheme = ThemeMode.system;
  int accent = 0xFF3F51B5;
  bool introAnimation = true;
  bool keepScreenOn = false;
  bool haptics = true;
  bool autoLocate = true;
  bool metric = true;
  CoordFormat coordFormat = CoordFormat.decimal;
  double? lastLat;
  double? lastLon;
  double? lastZoom;

  static const accents = <int>[
    0xFF3F51B5, 0xFF009688, 0xFFE64A19, 0xFF7B1FA2, 0xFF2E7D32, 0xFF0277BD,
  ];

  void _read() {
    mapTheme = MapTheme.values.elementAtOrNull(_p.getInt('mapTheme') ?? 0) ?? MapTheme.color;
    buildings3d = _p.getBool('buildings3d') ?? true;
    relief = _p.getBool('relief') ?? false;
    appTheme = ThemeMode.values.elementAtOrNull(_p.getInt('appTheme') ?? 0) ?? ThemeMode.system;
    accent = _p.getInt('accent') ?? 0xFF3F51B5;
    introAnimation = _p.getBool('intro') ?? true;
    keepScreenOn = _p.getBool('keepScreenOn') ?? false;
    haptics = _p.getBool('haptics') ?? true;
    autoLocate = _p.getBool('autoLocate') ?? true;
    metric = _p.getBool('metric') ?? true;
    coordFormat =
        CoordFormat.values.elementAtOrNull(_p.getInt('coordFormat') ?? 0) ?? CoordFormat.decimal;
    lastLat = _p.getDouble('lastLat');
    lastLon = _p.getDouble('lastLon');
    lastZoom = _p.getDouble('lastZoom');
  }

  Future<void> update(void Function() change) async {
    change();
    await _p.setInt('mapTheme', mapTheme.index);
    await _p.setBool('buildings3d', buildings3d);
    await _p.setBool('relief', relief);
    await _p.setInt('appTheme', appTheme.index);
    await _p.setInt('accent', accent);
    await _p.setBool('intro', introAnimation);
    await _p.setBool('keepScreenOn', keepScreenOn);
    await _p.setBool('haptics', haptics);
    await _p.setBool('autoLocate', autoLocate);
    await _p.setBool('metric', metric);
    await _p.setInt('coordFormat', coordFormat.index);
    notifyListeners();
  }

  Future<void> saveCamera(double lat, double lon, double zoom) async {
    lastLat = lat;
    lastLon = lon;
    lastZoom = zoom;
    await _p.setDouble('lastLat', lat);
    await _p.setDouble('lastLon', lon);
    await _p.setDouble('lastZoom', zoom);
  }

  /// Сбрасывает все настройки к значениям по умолчанию.
  Future<void> reset() async {
    await _p.clear();
    _read();
    notifyListeners();
  }
}
