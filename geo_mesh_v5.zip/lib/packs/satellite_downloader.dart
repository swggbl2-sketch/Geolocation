import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

/// Источники спутниковых снимков, которые можно СКАЧИВАТЬ на телефон.
///
/// Esri World Imagery здесь намеренно нет: её условия запрещают массовую
/// загрузку тайлов. Она остаётся только как онлайн-слой.
enum SatProvider {
  pnoa(
    title: 'PNOA, Испания (≈25–50 см/пиксель)',
    shortTitle: 'PNOA, Испания',
    urlTemplate:
        'https://www.ign.es/wmts/pnoa-ma?request=GetTile&service=WMTS&version=1.0.0'
        '&layer=OI.OrthoimageCoverage&style=default&format=image/jpeg'
        '&tilematrixset=GoogleMapsCompatible&tilematrix={z}&tilerow={y}&tilecol={x}',
    attribution: 'PNOA © Instituto Geográfico Nacional de España, CC BY 4.0',
    minSlider: 10,
    maxZoom: 19,
    avgTileKb: 28,
  ),
  eox(
    title: 'Sentinel-2, весь мир (10 м/пиксель)',
    shortTitle: 'Sentinel-2, мир',
    urlTemplate:
        'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2021_3857/default/g/{z}/{y}/{x}.jpg',
    attribution: 'Sentinel-2 cloudless © EOX IT Services GmbH, CC BY-NC-SA 4.0',
    minSlider: 6,
    maxZoom: 13,
    avgTileKb: 18,
  );

  const SatProvider({
    required this.title,
    required this.shortTitle,
    required this.urlTemplate,
    required this.attribution,
    required this.minSlider,
    required this.maxZoom,
    required this.avgTileKb,
  });

  final String title;
  final String shortTitle;
  final String urlTemplate;
  final String attribution;

  /// Минимальное значение ползунка детализации.
  final int minSlider;
  final int maxZoom;
  final int avgTileKb;

  /// Территория Испании (с Канарами и Балеарами), грубый прямоугольник.
  static bool inSpain(double lat, double lon) =>
      lat >= 27.4 && lat <= 43.9 && lon >= -18.5 && lon <= 4.6;

  static SatProvider autoFor(double lat, double lon) =>
      inSpain(lat, lon) ? pnoa : eox;
}

/// Готовая область для скачивания (прямоугольник).
class SatRegion {
  const SatRegion(
    this.title,
    this.west,
    this.south,
    this.east,
    this.north, {
    required this.eoxZoom,
    this.pnoaZoom,
  });

  final String title;
  final double west;
  final double south;
  final double east;
  final double north;

  /// Рекомендуемая детализация для Sentinel-2 и PNOA.
  final int eoxZoom;
  final int? pnoaZoom;

  double get centerLat => (south + north) / 2;
  double get centerLon => (west + east) / 2;

  static const List<SatRegion> presets = [
    SatRegion('Вся Европа', -11, 35, 40, 71, eoxZoom: 10),
    SatRegion('Иберия (Испания и Португалия)', -9.6, 35.9, 4.5, 43.9, eoxZoom: 12),
    SatRegion('Испания', -9.4, 35.9, 4.5, 43.9, eoxZoom: 12, pnoaZoom: 14),
    SatRegion('Валенсийское сообщество', -1.55, 37.8, 0.75, 40.8, eoxZoom: 13, pnoaZoom: 15),
    SatRegion('Провинция Аликанте', -1.25, 37.8, -0.05, 38.95, eoxZoom: 13, pnoaZoom: 16),
    SatRegion('Франция', -5.2, 41.3, 9.6, 51.1, eoxZoom: 12),
    SatRegion('Италия', 6.6, 36.6, 18.6, 47.1, eoxZoom: 12),
    SatRegion('Германия', 5.8, 47.2, 15.1, 55.1, eoxZoom: 12),
    SatRegion('Великобритания и Ирландия', -10.7, 49.8, 2.0, 61.0, eoxZoom: 12),
    SatRegion('Весь мир', -180, -85, 180, 85, eoxZoom: 8),
  ];
}

class SatelliteJob {
  const SatelliteJob({
    required this.id,
    required this.title,
    required this.provider,
    required this.west,
    required this.south,
    required this.east,
    required this.north,
    required this.minZoom,
    required this.maxZoom,
  });

  final String id;
  final String title;
  final SatProvider provider;
  final double west;
  final double south;
  final double east;
  final double north;
  final int minZoom;
  final int maxZoom;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'provider': provider.name,
        'west': west,
        'south': south,
        'east': east,
        'north': north,
        'minZoom': minZoom,
        'maxZoom': maxZoom,
      };

  static SatelliteJob fromJson(Map<String, dynamic> j) => SatelliteJob(
        id: j['id'] as String,
        title: j['title'] as String,
        provider: SatProvider.values.byName(j['provider'] as String),
        west: (j['west'] as num).toDouble(),
        south: (j['south'] as num).toDouble(),
        east: (j['east'] as num).toDouble(),
        north: (j['north'] as num).toDouble(),
        minZoom: (j['minZoom'] as num).toInt(),
        maxZoom: (j['maxZoom'] as num).toInt(),
      );
}

class SatelliteEstimate {
  const SatelliteEstimate(this.tiles, this.megabytes);
  final int tiles;
  final int megabytes;
}

class SatelliteDownloader {
  SatelliteDownloader._();

  /// Верхний предел одного задания (≈ 35 ГБ по оценке). Нужно, чтобы случайно
  /// не запустить загрузку на сотни гигабайт.
  static const int maxTiles = 2000000;
  static const _userAgent = 'GeoMesh/0.4 (offline map app)';

  static int _x(double lon, int z) =>
      (((lon + 180) / 360) * (1 << z)).floor().clamp(0, (1 << z) - 1);

  static int _y(double lat, int z) {
    final l = lat.clamp(-85.0511, 85.0511) * math.pi / 180;
    final v = (1 - math.log(math.tan(l) + 1 / math.cos(l)) / math.pi) / 2;
    return (v * (1 << z)).floor().clamp(0, (1 << z) - 1);
  }

  static int countTiles(SatelliteJob j) {
    var n = 0;
    for (var z = j.minZoom; z <= j.maxZoom; z++) {
      final x0 = _x(j.west, z), x1 = _x(j.east, z);
      final y0 = _y(j.north, z), y1 = _y(j.south, z);
      n += (x1 - x0 + 1) * (y1 - y0 + 1);
    }
    return n;
  }

  static SatelliteEstimate estimate(SatelliteJob j) {
    final n = countTiles(j);
    return SatelliteEstimate(n, (n * j.provider.avgTileKb / 1024).ceil());
  }

  /// Скачивает тайлы области в [target] (.mbtiles, jpg, схема TMS).
  ///
  /// Загрузку можно прервать и продолжить: уже сохранённые тайлы повторно
  /// не скачиваются. Файл [target] при ошибке и отмене НЕ удаляется.
  static Future<void> run({
    required SatelliteJob job,
    required File target,
    required void Function(double progress) onProgress,
    required bool Function() isCancelled,
    int concurrency = 6,
  }) async {
    final total = countTiles(job);
    if (total > maxTiles) {
      throw StateError('Слишком большая область: $total тайлов (максимум $maxTiles)');
    }

    final db = await openDatabase(
      target.path,
      version: 1,
      onCreate: (db, _) async {
        await db.execute('CREATE TABLE metadata (name TEXT, value TEXT)');
        await db.execute(
          'CREATE TABLE tiles (zoom_level INTEGER, tile_column INTEGER, '
          'tile_row INTEGER, tile_data BLOB)',
        );
        await db.execute(
          'CREATE UNIQUE INDEX tile_index ON tiles (zoom_level, tile_column, tile_row)',
        );
      },
    );

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15)
      ..maxConnectionsPerHost = concurrency + 2;

    // --- обход тайлов по зумам; на каждом зуме пропускаем уже скачанные
    var z = job.minZoom;
    var entered = false;
    Future<void>? entering;
    var x0 = 0, x1 = 0, y0 = 0, y1 = 0, cx = 0, cy = 0;
    var have = <int>{};
    var done = 0;

    Future<void> enterZoom() async {
      x0 = _x(job.west, z);
      x1 = _x(job.east, z);
      y0 = _y(job.north, z);
      y1 = _y(job.south, z);
      cx = x0;
      cy = y0;
      final rows = await db.rawQuery(
        'SELECT tile_column AS c, tile_row AS r FROM tiles WHERE zoom_level = ?',
        [z],
      );
      final n = 1 << z;
      have = {
        for (final r in rows)
          (r['c'] as int) * n + (n - 1 - (r['r'] as int)),
      };
    }

    Future<(int, int, int)?> next() async {
      while (true) {
        if (entering != null) {
          await entering;
          continue;
        }
        if (z > job.maxZoom) return null;
        if (!entered) {
          entering = enterZoom();
          await entering;
          entering = null;
          entered = true;
          continue;
        }
        if (cy > y1) {
          z++;
          entered = false;
          continue;
        }
        final tx = cx;
        final ty = cy;
        if (cx >= x1) {
          cx = x0;
          cy++;
        } else {
          cx++;
        }
        if (have.contains(tx * (1 << z) + ty)) {
          done++; // уже скачано раньше
          continue;
        }
        return (z, tx, ty);
      }
    }

    final pending = <(int, int, int, Uint8List)>[];
    var consecutiveFails = 0;
    var lastTick = DateTime.now();
    Object? fatal;

    Future<void> flush() async {
      if (pending.isEmpty) return;
      final chunk = List.of(pending);
      pending.clear();
      final b = db.batch();
      for (final t in chunk) {
        b.insert(
          'tiles',
          {
            'zoom_level': t.$1,
            'tile_column': t.$2,
            'tile_row': (1 << t.$1) - 1 - t.$3, // XYZ -> TMS
            'tile_data': t.$4,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await b.commit(noResult: true);
    }

    Future<void> worker() async {
      while (fatal == null && !isCancelled()) {
        final t = await next();
        if (t == null) return;
        final (tz, tx, ty) = t;
        final url = job.provider.urlTemplate
            .replaceAll('{z}', '$tz')
            .replaceAll('{x}', '$tx')
            .replaceAll('{y}', '$ty');
        final bytes = await _get(client, Uri.parse(url));
        if (bytes == null) {
          // тайла нет (за границей покрытия) или сеть недоступна
          if (++consecutiveFails > 60) {
            fatal = const HttpException('Нет связи с сервером снимков');
          }
        } else {
          consecutiveFails = 0;
          pending.add((tz, tx, ty, bytes));
          if (pending.length >= 64) await flush();
        }
        done++;
        if (DateTime.now().difference(lastTick).inMilliseconds > 300) {
          lastTick = DateTime.now();
          onProgress(done / total);
        }
      }
    }

    try {
      await Future.wait([for (var i = 0; i < concurrency; i++) worker()]);
      await flush(); // сохраняем всё, что успели скачать, даже при ошибке
      if (fatal != null) throw fatal!;
      if (isCancelled()) throw const HttpException('cancelled');

      final meta = <String, String>{
        'name': job.title,
        'format': 'jpg',
        'type': 'baselayer',
        'minzoom': '${job.minZoom}',
        'maxzoom': '${job.maxZoom}',
        'bounds': '${job.west},${job.south},${job.east},${job.north}',
        'attribution': job.provider.attribution,
      };
      await db.delete('metadata');
      final b = db.batch();
      meta.forEach((k, v) => b.insert('metadata', {'name': k, 'value': v}));
      await b.commit(noResult: true);

      final count =
          Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM tiles')) ?? 0;
      if (count == 0) {
        throw const HttpException('Сервер не отдал ни одного тайла');
      }
      onProgress(1);
    } finally {
      client.close(force: true);
      await db.close();
    }
  }

  static Future<Uint8List?> _get(HttpClient client, Uri uri) async {
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final req = await client.getUrl(uri);
        req.headers.set(HttpHeaders.userAgentHeader, _userAgent);
        final resp = await req.close().timeout(const Duration(seconds: 20));
        if (resp.statusCode == 200) {
          final bytes = await consolidateHttpClientResponseBytes(resp);
          // защита от «200 OK» с XML-ошибкой вместо картинки
          final jpeg = bytes.length > 3 && bytes[0] == 0xFF && bytes[1] == 0xD8;
          final png = bytes.length > 3 && bytes[0] == 0x89 && bytes[1] == 0x50;
          return (jpeg || png) ? bytes : null;
        }
        await resp.drain<void>();
        if (resp.statusCode == 404 || resp.statusCode == 204) return null;
      } catch (_) {
        // повторим
      }
      await Future<void>.delayed(Duration(milliseconds: 300 * (attempt + 1)));
    }
    return null;
  }
}
