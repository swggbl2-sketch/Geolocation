import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'package:wakelock_plus/wakelock_plus.dart';

import 'catalog_data.dart';
import 'satellite_downloader.dart';

/// Откуда брать пакеты по умолчанию: релизы вашего репозитория на GitHub.
/// Их создаёт workflow build-region-pack (тег `pack-<имя>`).
const String kReleaseBase =
    'https://github.com/swggbl28-ctrl/X/releases/download';

class PackInfo {
  const PackInfo({
    required this.id,
    required this.title,
    String? mapUrl,
    String? searchUrl,
    this.approxMb,
    this.group,
    this.groupTitle,
  })  : _mapUrl = mapUrl,
        _searchUrl = searchUrl;

  final String id;
  final String title;
  final String? _mapUrl;
  final String? _searchUrl;
  final int? approxMb;

  /// Страна, если она разбита на части (Германия -> земли).
  final String? group;
  final String? groupTitle;

  String? get customMapUrl => _mapUrl;

  String get mapUrl => _mapUrl ?? '$kReleaseBase/pack-$id/$id.mbtiles';

  /// SQLite-индекс для офлайн-поиска (необязателен).
  String? get searchUrl =>
      _searchUrl ?? (_mapUrl == null ? '$kReleaseBase/pack-$id/$id.search.sqlite' : null);

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'mapUrl': mapUrl,
        'searchUrl': searchUrl,
        'approxMb': approxMb,
      };

  static PackInfo fromJson(Map<String, dynamic> j) => PackInfo(
        id: j['id'] as String,
        title: j['title'] as String,
        mapUrl: j['mapUrl'] as String,
        searchUrl: j['searchUrl'] as String?,
        approxMb: j['approxMb'] as int?,
      );
}

class _Part {
  const _Part(this.url, this.size);
  final String url;
  final int size; // -1, если размер неизвестен
}

class InstalledPack {
  const InstalledPack({
    required this.id,
    required this.title,
    required this.mapPath,
    this.searchPath,
    required this.sizeBytes,
    this.kind = 'vector',
    this.maxZoom,
  });

  final String id;
  final String title;
  final String mapPath;
  final String? searchPath;
  final int sizeBytes;

  /// 'vector' (улицы, дома, поиск) или 'satellite' (снимки).
  final String kind;
  final int? maxZoom;

  bool get isSatellite => kind == 'satellite';

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'mapPath': mapPath,
        'searchPath': searchPath,
        'sizeBytes': sizeBytes,
        'kind': kind,
        'maxZoom': maxZoom,
      };

  static InstalledPack fromJson(Map<String, dynamic> j) => InstalledPack(
        id: j['id'] as String,
        title: j['title'] as String,
        mapPath: j['mapPath'] as String,
        searchPath: j['searchPath'] as String?,
        sizeBytes: (j['sizeBytes'] as num).toInt(),
        kind: (j['kind'] as String?) ?? 'vector',
        maxZoom: (j['maxZoom'] as num?)?.toInt(),
      );
}

/// Каталог, скачивание, хранение и удаление офлайн-пакетов карты.
class PackManager extends ChangeNotifier {
  PackManager._(this._dir);

  final Directory _dir;
  File get _manifest => File(p.join(_dir.path, 'packs.json'));

  /// Встроенный каталог. Пользователь может добавить свои пакеты по ссылке.
  static const List<PackInfo> builtIn = kBuiltInPacks;

  final List<PackInfo> _custom = [];
  final List<InstalledPack> _installed = [];
  final Map<String, double> _progress = {};
  final Map<String, String> _errors = {};
  final Set<String> _cancelled = {};

  List<PackInfo> get catalog => [...builtIn, ..._custom];
  List<InstalledPack> get installed => List.unmodifiable(_installed);
  List<InstalledPack> get installedVector =>
      _installed.where((e) => !e.isSatellite).toList();
  List<InstalledPack> get installedSatellite =>
      _installed.where((e) => e.isSatellite).toList();

  /// Названия идущих сейчас загрузок спутника (id -> название).
  final Map<String, String> _satTitles = {};
  final Map<String, SatelliteJob> _partial = {};
  Map<String, String> get satJobs => Map.unmodifiable(_satTitles);
  Map<String, double> get progress => Map.unmodifiable(_progress);
  String? errorOf(String id) => _errors[id];
  bool isInstalled(String id) => _installed.any((e) => e.id == id);
  bool isDownloading(String id) => _progress.containsKey(id);

  static Future<PackManager> open() async {
    final support = await getApplicationSupportDirectory();
    final dir = Directory(p.join(support.path, 'packs'));
    await dir.create(recursive: true);
    final m = PackManager._(dir);
    await m._load();
    return m;
  }

  Future<void> _load() async {
    if (!await _manifest.exists()) return;
    try {
      final j = jsonDecode(await _manifest.readAsString()) as Map<String, dynamic>;
      _custom.addAll(
        ((j['custom'] as List?) ?? const [])
            .map((e) => PackInfo.fromJson(Map<String, dynamic>.from(e as Map))),
      );
      for (final e in (j['installed'] as List?) ?? const []) {
        final pack = InstalledPack.fromJson(Map<String, dynamic>.from(e as Map));
        // файл мог быть удалён системой — тогда пропускаем запись
        if (await File(pack.mapPath).exists()) _installed.add(pack);
      }
      for (final e in (j['partial'] as List?) ?? const []) {
        final job = SatelliteJob.fromJson(Map<String, dynamic>.from(e as Map));
        if (await File(p.join(_dir.path, '${job.id}.partial')).exists()) {
          _partial[job.id] = job;
        }
      }
    } catch (e) {
      debugPrint('packs.json повреждён: $e');
    }
  }

  Future<void> _save() async {
    await _manifest.writeAsString(
      jsonEncode({
        'custom': _custom.map((e) => e.toJson()).toList(),
        'installed': _installed.map((e) => e.toJson()).toList(),
        'partial': _partial.values.map((e) => e.toJson()).toList(),
      }),
    );
  }

  Future<void> addCustom(PackInfo info) async {
    _custom.removeWhere((e) => e.id == info.id);
    _custom.add(info);
    await _save();
    notifyListeners();
  }

  void cancel(String id) => _cancelled.add(id);

  /// Скачивает спутниковые снимки области в локальный .mbtiles.
  /// Если загрузка прервана (отмена, сеть, закрытие приложения), уже скачанное
  /// сохраняется, и её можно продолжить через [downloadSatellite] с тем же заданием.
  Future<void> downloadSatellite(SatelliteJob job) async {
    if (isDownloading(job.id)) return;
    _errors.remove(job.id);
    _cancelled.remove(job.id);
    _progress[job.id] = 0;
    _satTitles[job.id] = job.title;
    _partial[job.id] = job;
    await _save();
    notifyListeners();

    final part = File(p.join(_dir.path, '${job.id}.partial'));
    final file = File(p.join(_dir.path, '${job.id}.mbtiles'));
    WakelockPlus.enable(); // экран не гаснет, пока идёт загрузка
    try {
      await SatelliteDownloader.run(
        job: job,
        target: part,
        isCancelled: () => _cancelled.contains(job.id),
        onProgress: (v) {
          _progress[job.id] = v;
          notifyListeners();
        },
      );
      if (await file.exists()) await file.delete();
      await part.rename(file.path);
      _installed.removeWhere((e) => e.id == job.id);
      _installed.add(
        InstalledPack(
          id: job.id,
          title: job.title,
          mapPath: file.path,
          sizeBytes: await file.length(),
          kind: 'satellite',
          maxZoom: job.maxZoom,
        ),
      );
      _partial.remove(job.id);
      await _save();
    } catch (e) {
      _errors[job.id] = _cancelled.contains(job.id)
          ? 'Остановлено. Скачанное сохранено, продолжите в «Офлайн-картах».'
          : 'Ошибка: $e. Скачанное сохранено, можно продолжить.';
    } finally {
      _progress.remove(job.id);
      _cancelled.remove(job.id);
      // название задания с ошибкой оставляем, чтобы показать причину
      if (!_errors.containsKey(job.id)) _satTitles.remove(job.id);
      if (_progress.isEmpty) WakelockPlus.disable();
      notifyListeners();
    }
  }

  /// Незавершённые загрузки спутника (можно продолжить или удалить).
  List<SatelliteJob> get partialJobs =>
      _partial.values.where((j) => !isDownloading(j.id)).toList();

  Future<void> deletePartial(String id) async {
    _partial.remove(id);
    _errors.remove(id);
    _satTitles.remove(id);
    final f = File(p.join(_dir.path, '$id.partial'));
    if (await f.exists()) await f.delete();
    await _save();
    notifyListeners();
  }

  void dismissError(String id) {
    _errors.remove(id);
    _satTitles.remove(id);
    notifyListeners();
  }

  /// Скачивает пакет в `<support>/packs/<id>.mbtiles` (и индекс поиска).
  /// Прерванная загрузка докачивается с того же места. Пакеты больше 1,9 ГБ
  /// лежат в релизе частями (манифест `<id>.parts.json`), приложение склеивает их.
  Future<void> download(PackInfo info) async {
    if (isDownloading(info.id)) return;
    _errors.remove(info.id);
    _cancelled.remove(info.id);
    _progress[info.id] = 0;
    notifyListeners();
    WakelockPlus.enable();

    final mapFile = File(p.join(_dir.path, '${info.id}.mbtiles'));
    final searchFile = File(p.join(_dir.path, '${info.id}.search.sqlite'));
    try {
      final parts = await _resolveParts(info);
      await _fetchParts(info.id, parts, mapFile, reportProgress: true);
      String? searchPath;
      if (info.searchUrl != null) {
        try {
          await _fetchParts(info.id, [_Part(info.searchUrl!, -1)], searchFile);
          searchPath = searchFile.path;
        } catch (e) {
          if (_cancelled.contains(info.id)) rethrow;
          debugPrint('индекс поиска недоступен: $e'); // не критично
        }
      }
      _installed.removeWhere((e) => e.id == info.id);
      _installed.add(
        InstalledPack(
          id: info.id,
          title: info.title,
          mapPath: mapFile.path,
          searchPath: searchPath,
          sizeBytes: await mapFile.length(),
        ),
      );
      await _save();
    } catch (e) {
      final text = '$e';
      if (_cancelled.contains(info.id)) {
        final part = File('${mapFile.path}.part');
        if (await part.exists()) await part.delete();
      }
      _errors[info.id] = _cancelled.contains(info.id)
          ? 'Отменено'
          : (text.contains('HTTP 404')
              ? 'Пакет ещё не собран. Запустите workflow build-packs в GitHub.'
              : 'Загрузка прервана, нажмите «Скачать» чтобы продолжить ($e)');
    } finally {
      _progress.remove(info.id);
      _cancelled.remove(info.id);
      if (_progress.isEmpty) WakelockPlus.disable();
      notifyListeners();
    }
  }

  /// Список частей: из манифеста, а если его нет, один файл.
  Future<List<_Part>> _resolveParts(PackInfo info) async {
    if (info.customMapUrl != null) return [_Part(info.mapUrl, -1)];
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.getUrl(Uri.parse('$kReleaseBase/pack-${info.id}/${info.id}.parts.json'));
      final resp = await req.close();
      if (resp.statusCode != 200) {
        await resp.drain<void>();
        return [_Part(info.mapUrl, -1)];
      }
      final j = jsonDecode(await utf8.decodeStream(resp)) as Map<String, dynamic>;
      final base = '$kReleaseBase/pack-${info.id}';
      return [
        for (final e in (j['parts'] as List))
          _Part('$base/${e['name']}', (e['size'] as num).toInt()),
      ];
    } catch (_) {
      return [_Part(info.mapUrl, -1)];
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _fetchParts(
    String id,
    List<_Part> parts,
    File target, {
    bool reportProgress = false,
  }) async {
    final part = File('${target.path}.part');
    final known = parts.every((e) => e.size >= 0);
    final total = known ? parts.fold<int>(0, (a, e) => a + e.size) : -1;
    var have = await part.exists() ? await part.length() : 0;
    if (known && have > total) {
      await part.delete();
      have = 0;
    }
    var received = have;
    var lastTick = DateTime.now();
    var skip = have;

    for (final pt in parts) {
      int offset;
      if (pt.size >= 0 && skip >= pt.size) {
        skip -= pt.size;
        continue;
      }
      offset = skip;
      skip = 0;

      final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
      try {
        final req = await client.getUrl(Uri.parse(pt.url));
        if (offset > 0) req.headers.set(HttpHeaders.rangeHeader, 'bytes=$offset-');
        final resp = await req.close(); // редиректы GitHub следуются автоматически
        if (resp.statusCode != 200 && resp.statusCode != 206) {
          await resp.drain<void>();
          throw HttpException('HTTP ${resp.statusCode}', uri: Uri.parse(pt.url));
        }
        var mode = FileMode.append;
        if (offset > 0 && resp.statusCode == 200) {
          // сервер не умеет докачку: начинаем файл заново
          mode = FileMode.write;
          received = 0;
          have = 0;
        }
        final len = resp.contentLength;
        final expected = total > 0 ? total : (len > 0 ? len + have : -1);
        final sink = part.openWrite(mode: mode);
        try {
          await for (final chunk in resp) {
            if (_cancelled.contains(id)) throw const HttpException('cancelled');
            sink.add(chunk);
            received += chunk.length;
            if (reportProgress &&
                expected > 0 &&
                DateTime.now().difference(lastTick).inMilliseconds > 250) {
              lastTick = DateTime.now();
              _progress[id] = (received / expected).clamp(0.0, 1.0);
              notifyListeners();
            }
          }
          await sink.flush();
        } finally {
          await sink.close();
        }
      } finally {
        client.close(force: true);
      }
    }
    if (await target.exists()) await target.delete();
    await part.rename(target.path);
  }

  Future<void> remove(String id) async {
    final idx = _installed.indexWhere((e) => e.id == id);
    if (idx < 0) return;
    final pack = _installed.removeAt(idx);
    for (final path in [pack.mapPath, pack.searchPath]) {
      if (path == null) continue;
      final f = File(path);
      if (await f.exists()) await f.delete();
    }
    await _save();
    notifyListeners();
  }
}
