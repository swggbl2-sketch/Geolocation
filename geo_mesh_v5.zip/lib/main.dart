import 'package:flutter/material.dart';

import 'mesh/geo_sharing_service.dart';
import 'mesh/mesh_transport.dart';
import 'mesh/peer_markers.dart';
import 'screens/map_screen.dart';
import 'settings/app_settings.dart';
import 'ui/splash.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await AppSettings.open();

  // Замените на реализацию поверх вашего BLE-мессенджера:
  //   class MyMeshTransport implements MeshTransport { ... }
  final transport = LoopbackMeshTransport();
  final markers = PeerMarkersController();
  final sharing = GeoSharingService(transport: transport, markers: markers);

  runApp(GeoMeshApp(settings: settings, sharing: sharing, markers: markers));
}

class GeoMeshApp extends StatefulWidget {
  const GeoMeshApp({super.key, required this.settings, required this.sharing, required this.markers});
  final AppSettings settings;
  final GeoSharingService sharing;
  final PeerMarkersController markers;

  @override
  State<GeoMeshApp> createState() => _GeoMeshAppState();
}

class _GeoMeshAppState extends State<GeoMeshApp> {
  bool _intro = true;

  ThemeData _theme(Brightness b) => ThemeData(
        colorSchemeSeed: Color(widget.settings.accent),
        brightness: b,
        useMaterial3: true,
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.settings,
      builder: (context, _) => MaterialApp(
        title: 'GeoMesh',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: widget.settings.appTheme,
        home: AnimatedSwitcher(
          duration: const Duration(milliseconds: 450),
          child: _intro
              ? SplashScreen(
                  key: const ValueKey('splash'),
                  animate: widget.settings.introAnimation,
                  onDone: () => setState(() => _intro = false),
                )
              : MapScreen(
                  key: const ValueKey('map'),
                  sharing: widget.sharing,
                  markers: widget.markers,
                  settings: widget.settings,
                ),
        ),
      ),
    );
  }
}
