import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';
import 'package:sqflite/sqflite.dart';

import '../packs/pack_manager.dart';
import 'coord_parser.dart';

bool _validLL(double lat, double lon) =>
    lat.isFinite && lon.isFinite && lat.abs() <= 90 && lon.abs() <= 180;

class PlaceResult {
  const PlaceResult({
    required this.name,
    required this.subtitle,
    required this.position,
    required this.offline,
  });

  final String name;
  final String subtitle;
  final LatLng position;

  /// true — найдено в локальном индексе, false — через интернет.
  final bool offline;
}

/// Поиск мест: сначала локальный индекс скачанных пакетов (работает без сети),
/// дополнительно онлайн (Nominatim/OSM) по всему миру, если сеть есть.
class SearchService {
  SearchService(this.packs, {this.builtinPlacesPath});

  final PackManager packs;

  /// Встроенный справочник городов мира (работает всегда, без сети).
  final String? builtinPlacesPath;
  final Map<String, Database> _dbs = {};

  static const _userAgent = 'GeoMesh/0.2 (offline map app)';

  /// Приведение к виду для поиска: нижний регистр, без диакритики.
  static const Map<String, String> _groups = {
    'a': 'àáâãäåāăą',
    'c': 'çćč',
    'd': 'ď',
    'e': 'èéêëēėęě',
    'i': 'ìíîïīį',
    'l': 'ł',
    'n': 'ñńň',
    'o': 'òóôõöøōő',
    'r': 'ŕř',
    's': 'śšş',
    't': 'ť',
    'u': 'ùúûüūůűų',
    'y': 'ýÿ',
    'z': 'źżž',
    'е': 'ё',
  };

  static final Map<String, String> _fold = {
    for (final e in _groups.entries)
      for (final ch in e.value.split('')) ch: e.key,
  };

  static String fold(String s) {
    final b = StringBuffer();
    for (final r in s.toLowerCase().runes) {
      final ch = String.fromCharCode(r);
      b.write(_fold[ch] ?? ch);
    }
    return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  Future<Database> _open(String path) async {
    return _dbs[path] ??= await openDatabase(path, readOnly: true);
  }

  Future<List<PlaceResult>> searchOffline(String query, {int limit = 25}) async {
    // Координаты вводятся как есть, поиск по базе не нужен.
    final coord = CoordParser.parse(query);
    if (coord != null) {
      return [
        PlaceResult(
          name: 'Координаты',
          subtitle: '${coord.latitude.toStringAsFixed(5)}, '
              '${coord.longitude.toStringAsFixed(5)}',
          position: coord,
          offline: true,
        ),
      ];
    }

    final q = fold(query);
    if (q.length < 2) return const [];
    final out = <PlaceResult>[];
    final seen = <String>{};
    final paths = <String>[
      ?builtinPlacesPath,
      for (final pack in packs.installedVector) ?pack.searchPath,
    ];
    for (final path in paths) {
      if (!await File(path).exists()) continue;
      try {
        final db = await _open(path);
        final rows = await db.rawQuery(
          'SELECT name, kind, addr, lat, lon FROM places '
          'WHERE name_norm LIKE ? OR name_norm LIKE ? '
          'ORDER BY importance DESC, length(name) ASC LIMIT ?',
          ['$q%', '% $q%', limit],
        );
        for (final r in rows) {
          final key = '${fold('${r['name']}')}|'
              '${(r['lat'] as num).toStringAsFixed(2)}|'
              '${(r['lon'] as num).toStringAsFixed(2)}';
          final la = (r['lat'] as num).toDouble(), lo = (r['lon'] as num).toDouble();
          if (!_validLL(la, lo)) continue;
          if (!seen.add(key)) continue;
          out.add(
            PlaceResult(
              name: '${r['name']}',
              subtitle: [r['kind'], r['addr']]
                  .where((e) => e != null && '$e'.isNotEmpty)
                  .join(' · '),
              position: LatLng(
                (r['lat'] as num).toDouble(),
                (r['lon'] as num).toDouble(),
              ),
              offline: true,
            ),
          );
        }
      } catch (e) {
        debugPrint('Ошибка поиска в $path: $e');
      }
    }
    return out;
  }

  /// Онлайн-поиск. При отсутствии сети тихо возвращает пустой список.
  Future<List<PlaceResult>> searchOnline(String query, {int limit = 8}) async {
    final q = query.trim();
    if (q.length < 3 || CoordParser.parse(q) != null) return const [];
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
        'q': q,
        'format': 'jsonv2',
        'limit': '$limit',
        'accept-language': 'ru,en',
      });
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.userAgentHeader, _userAgent);
      final resp = await req.close().timeout(const Duration(seconds: 7));
      if (resp.statusCode != 200) {
        await resp.drain<void>();
        return const [];
      }
      final body = await resp.transform(utf8.decoder).join();
      final list = jsonDecode(body) as List;
      return [
        for (final e in list)
          if (_validLL(double.tryParse('${e['lat']}') ?? double.nan,
              double.tryParse('${e['lon']}') ?? double.nan))
          PlaceResult(
            name: '${e['display_name']}'.split(',').first.trim(),
            subtitle: '${e['display_name']}',
            position: LatLng(
              double.parse('${e['lat']}'),
              double.parse('${e['lon']}'),
            ),
            offline: false,
          ),
      ];
    } catch (_) {
      return const [];
    } finally {
      client.close(force: true);
    }
  }

  Future<void> dispose() async {
    for (final db in _dbs.values) {
      await db.close();
    }
    _dbs.clear();
  }
}
