import 'package:latlong2/latlong.dart';

import '../geo/geohash.dart';

/// Разбор координат, введённых в строку поиска. Работает без сети.
///
/// Понимает:
///  * `38.3452, -0.4810`  /  `38.3452 -0.4810`  /  `38,3452 -0,4810`
///  * `38.3452 N 0.4810 W`
///  * `38°20'42.7"N 0°28'51.6"W`
///  * `GEO:eyz80euzn` (геохеш из mesh-сообщения)
/// Порядок: широта, затем долгота. Если первое число по модулю больше 90,
/// а второе нет, значения меняются местами.
class CoordParser {
  CoordParser._();

  static final RegExp _dms = RegExp(
    r'''(?<![\d.,])(\d{1,3})\s*°\s*(?:(\d{1,2})\s*['′’]\s*)?(?:(\d{1,2}(?:[.,]\d+)?)\s*(?:"|″|'')\s*)?([NSEWnsew])?''',
  );
  static final RegExp _num = RegExp(r'[-+]?\d+(?:[.,]\d+)?');
  static final RegExp _hemi = RegExp(r'[NSEWnsew]');

  static LatLng? parse(String input) {
    final s = input.trim();
    if (s.isEmpty) return null;

    if (s.length > 4 && s.substring(0, 4).toUpperCase() == 'GEO:') {
      final h = s.substring(4).trim().toLowerCase();
      if (!Geohash.isValid(h)) return null;
      return Geohash.decode(h);
    }

    final dms = _dms.allMatches(s).toList();
    if (dms.length == 2) {
      final a = _fromDms(dms[0]);
      final b = _fromDms(dms[1]);
      if (a != null && b != null) return _order(a, b, dms[0], dms[1]);
    }

    // Только цифры, разделители и буквы сторон света.
    final stripped = s.replaceAll(_hemi, '').replaceAll(RegExp(r'[\s,;.\-+°0-9]'), '');
    if (stripped.isNotEmpty) return null;

    final nums = _num.allMatches(s).toList();
    if (nums.length != 2) return null;
    var a = double.tryParse(nums[0].group(0)!.replaceAll(',', '.'));
    var b = double.tryParse(nums[1].group(0)!.replaceAll(',', '.'));
    if (a == null || b == null) return null;

    // Буквы сторон света: N/S относятся к широте, E/W к долготе.
    final letters = _hemi.allMatches(s).map((m) => m.group(0)!.toUpperCase()).toList();
    for (final l in letters) {
      if (l == 'S' && a > 0) a = -a;
      if (l == 'W' && b > 0) b = -b;
    }
    return _validate(a, b);
  }

  static double? _fromDms(RegExpMatch m) {
    final d = double.parse(m.group(1)!);
    final min = m.group(2) == null ? 0.0 : double.parse(m.group(2)!);
    final sec = m.group(3) == null ? 0.0 : double.parse(m.group(3)!.replaceAll(',', '.'));
    if (min >= 60 || sec >= 60) return null;
    var v = d + min / 60 + sec / 3600;
    final h = m.group(4)?.toUpperCase();
    if (h == 'S' || h == 'W') v = -v;
    return v;
  }

  static LatLng? _order(double a, double b, RegExpMatch ma, RegExpMatch mb) {
    final ha = ma.group(4)?.toUpperCase();
    final hb = mb.group(4)?.toUpperCase();
    // Если указана сторона света «E/W» у первого числа, то оно долгота.
    if ((ha == 'E' || ha == 'W') && (hb == 'N' || hb == 'S')) {
      return _validate(b, a);
    }
    return _validate(a, b);
  }

  static LatLng? _validate(double a, double b) {
    var lat = a;
    var lon = b;
    if (lat.abs() > 90 && lon.abs() <= 90) {
      final t = lat;
      lat = lon;
      lon = t;
    }
    if (lat.abs() > 90 || lon.abs() > 180) return null;
    return LatLng(lat, lon);
  }
}
