import 'dart:io';

import 'package:flutter/material.dart';

import '../marks/mark.dart';
import '../marks/marks_store.dart';
import 'mark_editor.dart';

/// Список сохранённых меток. Нажатие возвращает метку на карту (перелёт).
class MarksScreen extends StatefulWidget {
  const MarksScreen({super.key, required this.store});

  final MarksStore store;

  @override
  State<MarksScreen> createState() => _MarksScreenState();
}

class _MarksScreenState extends State<MarksScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Мои метки')),
      body: ListenableBuilder(
        listenable: widget.store,
        builder: (context, _) {
          final all = widget.store.marks;
          final q = _q.text.trim().toLowerCase();
          final list = q.isEmpty
              ? all
              : all
                  .where((m) =>
                      m.title.toLowerCase().contains(q) ||
                      m.note.toLowerCase().contains(q))
                  .toList();
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  controller: _q,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Поиск по названию и описанию',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Text(
                            all.isEmpty
                                ? 'Меток пока нет.\nДолго нажмите на карту, чтобы '
                                    'выбрать точку, и нажмите «Сохранить метку».'
                                : 'Ничего не найдено.',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      )
                    : ListView.separated(
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) => _tile(context, list[i]),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _tile(BuildContext context, Mark m) {
    final thumb = m.photos.isEmpty ? null : m.photos.first;
    return ListTile(
      leading: SizedBox(
        width: 52,
        height: 52,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: thumb == null
              ? Container(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: const Icon(Icons.place),
                )
              : Image.file(
                  File(thumb),
                  fit: BoxFit.cover,
                  cacheWidth: 156,
                  errorBuilder: (_, __, ___) => const Icon(Icons.broken_image),
                ),
        ),
      ),
      title: Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        '${m.position.latitude.toStringAsFixed(5)}, '
        '${m.position.longitude.toStringAsFixed(5)}'
        '${m.note.isEmpty ? '' : '\n${m.note}'}',
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
      ),
      isThreeLine: m.note.isNotEmpty,
      trailing: IconButton(
        icon: const Icon(Icons.edit_outlined),
        tooltip: 'Изменить',
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute<MarkEditResult>(
            builder: (_) => MarkEditorScreen(store: widget.store, mark: m),
          ),
        ),
      ),
      onTap: () => Navigator.pop(context, m),
    );
  }
}
