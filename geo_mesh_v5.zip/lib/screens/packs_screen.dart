import 'package:flutter/material.dart';

import '../packs/pack_manager.dart';

/// Скачивание и удаление офлайн-пакетов карты.
class PacksScreen extends StatefulWidget {
  const PacksScreen({super.key, required this.packs});

  final PackManager packs;

  @override
  State<PacksScreen> createState() => _PacksScreenState();
}

class _PacksScreenState extends State<PacksScreen> {
  PackManager get packs => widget.packs;
  String _q = '';

  bool _match(PackInfo i) {
    if (_q.isEmpty) return true;
    final q = _q.toLowerCase();
    return i.title.toLowerCase().contains(q) ||
        (i.groupTitle ?? '').toLowerCase().contains(q) ||
        i.id.contains(q);
  }

  List<Widget> _catalogWidgets(BuildContext context, List<PackInfo> items) {
    final whole = <PackInfo>[];
    final groups = <String, List<PackInfo>>{};
    for (final i in items.where(_match)) {
      if (i.group == null) {
        whole.add(i);
      } else {
        (groups[i.group!] ??= []).add(i);
      }
    }
    // страна с одним пакетом показывается как обычная плитка, остальные папками
    final entries = <(String, Widget)>[
      for (final i in whole) (i.title, _tile(context, i)),
      for (final g in groups.entries)
        (g.value.first.groupTitle ?? g.key, _groupTile(context, g.value)),
    ]..sort((a, b) => a.$1.compareTo(b.$1));
    return [for (final e in entries) e.$2];
  }

  Widget _groupTile(BuildContext context, List<PackInfo> list) {
    final done = list.where((e) => packs.isInstalled(e.id)).length;
    final mb = list.fold<int>(0, (a, e) => a + (e.approxMb ?? 0));
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        key: PageStorageKey('g_${list.first.group}'),
        initiallyExpanded: _q.isNotEmpty,
        leading: Icon(done > 0 ? Icons.folder_special : Icons.folder_outlined),
        title: Text(list.first.groupTitle ?? list.first.group!),
        subtitle: Text('${list.length} частей · ≈ $mb МБ всего'
            '${done > 0 ? ' · скачано $done' : ''}'),
        children: [for (final i in list) _tile(context, i)],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Офлайн-карты')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addCustom(context),
        icon: const Icon(Icons.add_link),
        label: const Text('Пакет по ссылке'),
      ),
      body: ListenableBuilder(
        listenable: packs,
        builder: (context, _) {
          final items = packs.catalog;
          return ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 8),
                child: SearchBar(
                  hintText: 'Найти страну или регион',
                  leading: const Icon(Icons.search),
                  elevation: const WidgetStatePropertyAll(0),
                  onChanged: (v) => setState(() => _q = v.trim()),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(8),
                child: Text(
                  'Скачайте районы заранее, пока есть интернет. '
                  'Скачанные пакеты работают без сети: улицы, дома, 3D-здания, '
                  'подписи и поиск мест.',
                ),
              ),
              ..._catalogWidgets(context, items),
              const Padding(
                padding: EdgeInsets.fromLTRB(8, 16, 8, 4),
                child: Text(
                  'Спутниковые снимки',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              if (packs.installedSatellite.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text(
                    'Нет скачанных областей. На карте приблизьте нужное место и '
                    'нажмите кнопку со спутником.',
                  ),
                ),
              for (final j in packs.partialJobs)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.pause_circle_outline),
                    title: Text(j.title),
                    subtitle: Text(packs.errorOf(j.id) ?? 'Загрузка прервана'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.play_arrow),
                          tooltip: 'Продолжить',
                          onPressed: () => packs.downloadSatellite(j),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          tooltip: 'Удалить',
                          onPressed: () => packs.deletePartial(j.id),
                        ),
                      ],
                    ),
                  ),
                ),
              for (final s in packs.installedSatellite)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.satellite_alt, color: Colors.green),
                    title: Text(s.title),
                    subtitle: Text('до z${s.maxZoom ?? '?'} · ${_mb(s.sizeBytes)}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => packs.remove(s.id),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _tile(BuildContext context, PackInfo info) {
    final installed = packs.installed.where((e) => e.id == info.id).firstOrNull;
    final progress = packs.progress[info.id];
    final error = packs.errorOf(info.id);

    Widget trailing;
    if (progress != null) {
      trailing = IconButton(
        icon: const Icon(Icons.close),
        tooltip: 'Отменить',
        onPressed: () => packs.cancel(info.id),
      );
    } else if (installed != null) {
      trailing = IconButton(
        icon: const Icon(Icons.delete_outline),
        tooltip: 'Удалить',
        onPressed: () => _confirmDelete(context, info),
      );
    } else {
      trailing = IconButton(
        icon: const Icon(Icons.download),
        tooltip: 'Скачать',
        onPressed: () => packs.download(info),
      );
    }

    final String subtitle;
    if (installed != null) {
      subtitle = 'Установлено · ${_mb(installed.sizeBytes)}'
          '${installed.searchPath == null ? ' · без поиска' : ''}';
    } else if (progress != null) {
      subtitle = 'Загрузка ${(progress * 100).round()}%';
    } else {
      subtitle = info.approxMb == null ? 'Не скачано' : '≈ ${info.approxMb} МБ';
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(
          children: [
            ListTile(
              leading: Icon(
                installed != null ? Icons.offline_pin : Icons.map_outlined,
                color: installed != null ? Colors.green : null,
              ),
              title: Text(info.title),
              subtitle: Text(subtitle),
              trailing: trailing,
            ),
            if (progress != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: LinearProgressIndicator(value: progress),
              ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Text(
                  error,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
          ],
        ),
      ),
    );
  }

  static String _mb(int bytes) => '${(bytes / 1e6).toStringAsFixed(0)} МБ';

  Future<void> _confirmDelete(BuildContext context, PackInfo info) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Удалить «${info.title}»?'),
        content: const Text('Карта этого района станет недоступна без сети.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok == true) await packs.remove(info.id);
  }

  Future<void> _addCustom(BuildContext context) async {
    final name = TextEditingController();
    final mapUrl = TextEditingController();
    final searchUrl = TextEditingController();
    final info = await showDialog<PackInfo>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Добавить пакет'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Название'),
              ),
              TextField(
                controller: mapUrl,
                decoration: const InputDecoration(labelText: 'Ссылка на .mbtiles'),
                keyboardType: TextInputType.url,
              ),
              TextField(
                controller: searchUrl,
                decoration: const InputDecoration(
                  labelText: 'Ссылка на индекс поиска (необязательно)',
                ),
                keyboardType: TextInputType.url,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Отмена')),
          FilledButton(
            onPressed: () {
              final n = name.text.trim();
              final u = mapUrl.text.trim();
              if (n.isEmpty || !u.startsWith('http')) return;
              final id = 'c${DateTime.now().millisecondsSinceEpoch}';
              final s = searchUrl.text.trim();
              Navigator.pop(
                c,
                PackInfo(
                  id: id,
                  title: n,
                  mapUrl: u,
                  searchUrl: s.startsWith('http') ? s : null,
                ),
              );
            },
            child: const Text('Добавить'),
          ),
        ],
      ),
    );
    if (info != null) {
      await packs.addCustom(info);
      await packs.download(info);
    }
  }
}
