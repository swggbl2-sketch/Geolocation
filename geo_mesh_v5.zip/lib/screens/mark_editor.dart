import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';

import '../marks/mark.dart';
import '../marks/marks_store.dart';
import '../search/coord_parser.dart';

/// Результат закрытия редактора.
enum MarkEditResult { saved, deleted }

/// Создание и редактирование метки: название, координаты, описание, фото.
class MarkEditorScreen extends StatefulWidget {
  const MarkEditorScreen({
    super.key,
    required this.store,
    this.mark,
    this.initialPosition,
    this.initialTitle,
  });

  final MarksStore store;

  /// Редактируемая метка; null — создаём новую.
  final Mark? mark;
  final LatLng? initialPosition;
  final String? initialTitle;

  @override
  State<MarkEditorScreen> createState() => _MarkEditorScreenState();
}

class _MarkEditorScreenState extends State<MarkEditorScreen> {
  late final TextEditingController _title;
  late final TextEditingController _coords;
  late final TextEditingController _note;
  late final List<String> _photos;

  /// Фото, добавленные в этой сессии: при «Отмене» их копии удаляем.
  final List<String> _added = [];

  /// Фото, убранные в этой сессии: файлы удаляем только после «Сохранить».
  final List<String> _removed = [];

  String? _coordError;
  bool _busy = false;

  bool get _isNew => widget.mark == null;

  @override
  void initState() {
    super.initState();
    final m = widget.mark;
    final pos = m?.position ?? widget.initialPosition ?? const LatLng(0, 0);
    _title = TextEditingController(text: m?.title ?? widget.initialTitle ?? '');
    _coords = TextEditingController(text: _fmt(pos));
    _note = TextEditingController(text: m?.note ?? '');
    _photos = List<String>.of(m?.photos ?? const []);
  }

  @override
  void dispose() {
    _title.dispose();
    _coords.dispose();
    _note.dispose();
    super.dispose();
  }

  static String _fmt(LatLng p) =>
      '${p.latitude.toStringAsFixed(6)}, ${p.longitude.toStringAsFixed(6)}';

  Future<void> _addPhotos(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final List<XFile> files;
      if (source == ImageSource.camera) {
        final f = await picker.pickImage(
          source: source,
          imageQuality: 88,
          maxWidth: 2560,
        );
        files = f == null ? const [] : [f];
      } else {
        files = await picker.pickMultiImage(imageQuality: 88, maxWidth: 2560);
      }
      for (final f in files) {
        final copy = await widget.store.importPhoto(f.path);
        _added.add(copy);
        _photos.add(copy);
      }
      if (mounted) setState(() {});
    } catch (e) {
      _snack('Не удалось добавить фото: $e');
    }
  }

  void _removePhoto(String path) {
    setState(() => _photos.remove(path));
    if (_added.remove(path)) {
      widget.store.deletePhotoFile(path); // добавили и сразу убрали
    } else {
      _removed.add(path);
    }
  }

  Future<void> _pickSource() async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Из галереи'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Снять на камеру'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
          ],
        ),
      ),
    );
    if (src != null) await _addPhotos(src);
  }

  Future<void> _save() async {
    final pos = CoordParser.parse(_coords.text);
    if (pos == null) {
      setState(() => _coordError = 'Не разобрал координаты. Пример: 38.3452, -0.4810');
      return;
    }
    setState(() {
      _coordError = null;
      _busy = true;
    });
    final title = _title.text.trim().isEmpty ? 'Метка' : _title.text.trim();
    final m = widget.mark ?? Mark(title: title, position: pos);
    m
      ..title = title
      ..position = pos
      ..note = _note.text.trim()
      ..photos = List<String>.of(_photos);
    await widget.store.save(m);
    for (final path in _removed) {
      await widget.store.deletePhotoFile(path);
    }
    _added.clear(); // теперь принадлежат метке
    if (mounted) Navigator.pop(context, MarkEditResult.saved);
  }

  Future<void> _delete() async {
    final m = widget.mark;
    if (m == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить метку?'),
        content: Text('«${m.title}» и её фото будут удалены с телефона.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await widget.store.delete(m);
    for (final path in _added) {
      await widget.store.deletePhotoFile(path);
    }
    if (mounted) Navigator.pop(context, MarkEditResult.deleted);
  }

  Future<bool> _discard() async {
    for (final path in _added) {
      await widget.store.deletePhotoFile(path);
    }
    return true;
  }

  void _snack(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(t)));
  }

  void _openPhoto(int index) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _PhotoViewer(paths: List.of(_photos), initial: index),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await _discard();
        if (context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(_isNew ? 'Новая метка' : 'Метка'),
          actions: [
            if (!_isNew)
              IconButton(
                icon: const Icon(Icons.delete_outline),
                tooltip: 'Удалить',
                onPressed: _busy ? null : _delete,
              ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Название (подпись на карте)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _coords,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                labelText: 'Координаты',
                helperText: 'Широта, долгота. Можно и 38°20′42″N 0°28′52″W',
                errorText: _coordError,
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              minLines: 3,
              maxLines: 8,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Описание',
                alignLabelWithHint: true,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Text('Фото (${_photos.length})',
                    style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                TextButton.icon(
                  onPressed: _pickSource,
                  icon: const Icon(Icons.add_a_photo),
                  label: const Text('Добавить'),
                ),
              ],
            ),
            if (_photos.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('Фото необязательны.'),
              )
            else
              SizedBox(
                height: 104,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _photos.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => Stack(
                    children: [
                      GestureDetector(
                        onTap: () => _openPhoto(i),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(
                            File(_photos[i]),
                            width: 104,
                            height: 104,
                            fit: BoxFit.cover,
                            cacheWidth: 312,
                            errorBuilder: (_, __, ___) => Container(
                              width: 104,
                              height: 104,
                              color: Colors.black12,
                              child: const Icon(Icons.broken_image),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        top: 0,
                        right: 0,
                        child: InkWell(
                          onTap: () => _removePhoto(_photos[i]),
                          child: const CircleAvatar(
                            radius: 12,
                            backgroundColor: Colors.black54,
                            child: Icon(Icons.close, size: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.check),
              label: const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
  }
}

class _PhotoViewer extends StatelessWidget {
  const _PhotoViewer({required this.paths, required this.initial});

  final List<String> paths;
  final int initial;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: PageView.builder(
        controller: PageController(initialPage: initial),
        itemCount: paths.length,
        itemBuilder: (_, i) => InteractiveViewer(
          maxScale: 6,
          child: Center(child: Image.file(File(paths[i]))),
        ),
      ),
    );
  }
}
