import 'package:flutter/material.dart';

import '../map/map_style.dart';
import '../marks/marks_store.dart';
import '../packs/pack_manager.dart';
import '../settings/app_settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.settings, this.packs, this.marks});

  final AppSettings settings;
  final PackManager? packs;
  final MarksStore? marks;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListenableBuilder(
        listenable: settings,
        builder: (context, _) {
          final s = settings;
          return ListView(
            padding: const EdgeInsets.only(bottom: 32),
            children: [
              _section(context, 'Внешний вид'),
              ListTile(
                title: const Text('Тема приложения'),
                subtitle: SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Авто')),
                    ButtonSegment(value: ThemeMode.light, label: Text('Светлая')),
                    ButtonSegment(value: ThemeMode.dark, label: Text('Тёмная')),
                  ],
                  selected: {s.appTheme},
                  onSelectionChanged: (v) => s.update(() => s.appTheme = v.first),
                ),
              ),
              ListTile(
                title: const Text('Акцентный цвет'),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Wrap(
                    spacing: 10,
                    children: [
                      for (final c in AppSettings.accents)
                        GestureDetector(
                          onTap: () => s.update(() => s.accent = c),
                          child: CircleAvatar(
                            radius: 16,
                            backgroundColor: Color(c),
                            child: s.accent == c
                                ? const Icon(Icons.check, size: 18, color: Colors.white)
                                : null,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              SwitchListTile(
                title: const Text('Анимация при запуске'),
                value: s.introAnimation,
                onChanged: (v) => s.update(() => s.introAnimation = v),
              ),
              _section(context, 'Карта'),
              ListTile(
                title: const Text('Тема карты по умолчанию'),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Wrap(
                    spacing: 8,
                    children: [
                      for (final t in MapTheme.values)
                        ChoiceChip(
                          label: Text(t.title),
                          selected: s.mapTheme == t,
                          onSelected: (_) => s.update(() => s.mapTheme = t),
                        ),
                    ],
                  ),
                ),
              ),
              SwitchListTile(
                title: const Text('3D-здания'),
                value: s.buildings3d,
                onChanged: (v) => s.update(() => s.buildings3d = v),
              ),
              SwitchListTile(
                title: const Text('Рельеф (тени гор)'),
                subtitle: const Text('Нужен интернет, офлайн только кэш'),
                value: s.relief,
                onChanged: (v) => s.update(() => s.relief = v),
              ),
              _section(context, 'Координаты и единицы'),
              for (final f in CoordFormat.values)
                RadioListTile<CoordFormat>(
                  title: Text(f.title),
                  subtitle: Text(f.example),
                  value: f,
                  groupValue: s.coordFormat,
                  onChanged: (v) => s.update(() => s.coordFormat = v!),
                ),
              SwitchListTile(
                title: const Text('Метрическая система'),
                subtitle: Text(s.metric ? 'Километры и метры' : 'Мили и футы'),
                value: s.metric,
                onChanged: (v) => s.update(() => s.metric = v),
              ),
              _section(context, 'Устройство'),
              SwitchListTile(
                title: const Text('Не гасить экран'),
                subtitle: const Text('Пока открыта карта'),
                value: s.keepScreenOn,
                onChanged: (v) => s.update(() => s.keepScreenOn = v),
              ),
              SwitchListTile(
                title: const Text('Определять местоположение при запуске'),
                value: s.autoLocate,
                onChanged: (v) => s.update(() => s.autoLocate = v),
              ),
              SwitchListTile(
                title: const Text('Вибрация'),
                value: s.haptics,
                onChanged: (v) => s.update(() => s.haptics = v),
              ),
              _section(context, 'Данные'),
              ListTile(
                leading: const Icon(Icons.restart_alt),
                title: const Text('Сбросить настройки'),
                subtitle: const Text('Карты и метки останутся'),
                onTap: () => _confirm(
                  context,
                  'Сбросить настройки?',
                  'Все параметры вернутся к значениям по умолчанию.',
                  () => s.reset(),
                ),
              ),
              ListTile(
                leading: Icon(Icons.delete_forever, color: Theme.of(context).colorScheme.error),
                title: const Text('Удалить все данные'),
                subtitle: const Text('Настройки, метки и скачанные карты'),
                onTap: () => _confirm(
                  context,
                  'Удалить все данные?',
                  'Будут удалены настройки, все метки и все скачанные карты. '
                      'Отменить это нельзя.',
                  () async {
                    await s.reset();
                    final pk = packs;
                    if (pk != null) {
                      for (final e in [...pk.installed]) {
                        await pk.remove(e.id);
                      }
                    }
                    final mk = marks;
                    if (mk != null) {
                      for (final m in [...mk.marks]) {
                        await mk.delete(m);
                      }
                    }
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _section(BuildContext context, String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(
          t.toUpperCase(),
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                letterSpacing: 1.2,
              ),
        ),
      );

  Future<void> _confirm(BuildContext context, String title, String body, Future<void> Function() ok) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Да')),
        ],
      ),
    );
    if (yes == true) {
      await ok();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Готово')));
      }
    }
  }
}
