import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:path/path.dart' as p;

import '../location/location_service.dart';
import '../map/map_assets.dart';
import '../map/map_style.dart';
import '../marks/mark.dart';
import '../marks/marks_store.dart';
import '../mesh/geo_sharing_service.dart';
import '../mesh/peer_markers.dart';
import '../nav/navigation_controller.dart';
import '../nav/routing_service.dart';
import '../packs/pack_manager.dart';
import '../packs/satellite_downloader.dart';
import '../search/search_service.dart';
import '../settings/app_settings.dart';
import '../ui/coord_format.dart';
import 'settings_screen.dart';
import 'mark_editor.dart';
import 'marks_screen.dart';
import 'packs_screen.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({
    super.key,
    required this.sharing,
    required this.markers,
    required this.settings,
  });

  final AppSettings settings;

  final GeoSharingService sharing;
  final PeerMarkersController markers;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  static const _alicante = LatLng(38.3452, -0.4810);

  MapAssets? _assets;
  PackManager? _packs;
  MarksStore? _marks;
  SearchService? _search;
  final _nav = NavigationController();
  final _routing = RoutingService();
  final _location = LocationService();

  MapLibreMapController? _map;
  String? _stylePath;
  int _rev = 0;
  String _packSig = '';

  MapTheme _theme = MapTheme.color;
  bool _buildings3d = true;
  bool _relief = false;

  bool _locGranted = false;
  MyLocationTrackingMode _track = MyLocationTrackingMode.none;
  ll.LatLng? _me;
  double _bearing = 0;
  double _pitch = 0;

  PlaceResult? _picked;
  List<PlaceResult> _results = const [];
  bool _searching = false;
  Timer? _debounce;
  final _query = TextEditingController();
  final _focus = FocusNode();

  bool _routing_ = false;
  bool _rerouting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  void _applySettings() {
    final st = widget.settings;
    _theme = st.mapTheme;
    _buildings3d = st.buildings3d;
    _relief = st.relief;
    NavigationController.metric = st.metric;
    st.keepScreenOn ? WakelockPlus.enable() : WakelockPlus.disable();
  }

  void _onSettings() {
    final st = widget.settings;
    final changed = _theme != st.mapTheme || _buildings3d != st.buildings3d || _relief != st.relief;
    _applySettings();
    if (changed && _assets != null && _packs != null) _restyle();
    if (mounted) setState(() {});
  }

  Future<void> _init() async {
    _applySettings();
    widget.settings.addListener(_onSettings);
    try {
      final assets = await MapAssets.prepare();
      final packs = await PackManager.open();
      _assets = assets;
      _packs = packs;
      _marks = await MarksStore.open();
      _marks!.addListener(_pushMarks);
      _search = SearchService(packs, builtinPlacesPath: assets.placesPath);
      _packSig = _sigOf(packs);
      packs.addListener(_onPacksChanged);
      await _writeStyle();
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _error = 'Не удалось подготовить карту: $e');
    }
    widget.markers.addListener(_pushPeers);
    _nav.onNeedReroute = _reroute;
    _nav.addListener(_onNav);
    if (widget.settings.autoLocate) _initLocation();
  }

  Future<void> _initLocation() async {
    try {
      await _location.ensurePermission();
      if (mounted) setState(() => _locGranted = true);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  // ---------------------------------------------------------------- стиль

  String _sigOf(PackManager m) => m.installed.map((e) => e.mapPath).join('|');

  void _onPacksChanged() {
    final sig = _sigOf(_packs!);
    if (sig != _packSig) {
      _packSig = sig;
      _restyle();
    }
  }

  Future<void> _writeStyle() async {
    final json = MapStyleBuilder.build(
      theme: _theme,
      assets: _assets!,
      packPaths: _packs!.installedVector.map((e) => e.mapPath).toList(),
      satPacks: [
        for (final s in _packs!.installedSatellite) SatLocal(s.mapPath, s.maxZoom ?? 18),
      ],
      buildings3d: _buildings3d,
      relief: _relief,
    );
    final file = File(p.join(_assets!.root, 'style_${_rev++}.json'));
    await file.writeAsString(json);
    final old = _stylePath;
    _stylePath = file.path;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
  }

  Future<void> _restyle() async {
    if (_assets == null || _packs == null) return;
    await _writeStyle();
    await _map?.setStyle(_stylePath!);
  }

  Future<void> _onStyleLoaded() async {
    // setStyle сбрасывает данные наложений, поэтому заполняем заново.
    await _pushRoute();
    await _pushPick();
    _pushPeers();
    _pushMarks();
  }

  // ------------------------------------------------------- GeoJSON-наложения

  Map<String, dynamic> _fc(List<Map<String, dynamic>> f) =>
      {'type': 'FeatureCollection', 'features': f};

  Map<String, dynamic> _pt(ll.LatLng p, [Map<String, dynamic> props = const {}]) => {
        'type': 'Feature',
        'properties': props,
        'geometry': {
          'type': 'Point',
          'coordinates': [p.longitude, p.latitude],
        },
      };

  Future<void> _setSrc(String id, Map<String, dynamic> data) async {
    try {
      await _map?.setGeoJsonSource(id, data);
    } catch (_) {
      // стиль мог быть ещё не загружен — данные придут из _onStyleLoaded
    }
  }

  Future<void> _pushRoute() async {
    final r = _nav.route;
    await _setSrc(
      OverlayIds.route,
      _fc([
        if (r != null)
          {
            'type': 'Feature',
            'properties': {},
            'geometry': {
              'type': 'LineString',
              'coordinates': [
                for (final q in r.points) [q.longitude, q.latitude],
              ],
            },
          },
      ]),
    );
    final d = _nav.destination;
    await _setSrc(OverlayIds.dest, _fc([if (d != null) _pt(d)]));
  }

  Future<void> _pushPick() async {
    final pk = _picked;
    await _setSrc(OverlayIds.pick, _fc([if (pk != null) _pt(pk.position)]));
  }

  void _pushMarks() {
    final store = _marks;
    if (store == null) return;
    _setSrc(
      OverlayIds.marks,
      _fc([
        for (final m in store.marks)
          _pt(m.position, {'id': m.id, 'name': m.title}),
      ]),
    );
  }

  /// Открывает редактор: новая метка в точке [pos] или правка [mark].
  Future<void> _editMark({Mark? mark, ll.LatLng? pos, String? title}) async {
    final store = _marks;
    if (store == null) return;
    final res = await Navigator.of(context).push<MarkEditResult>(
      MaterialPageRoute<MarkEditResult>(
        builder: (_) => MarkEditorScreen(
          store: store,
          mark: mark,
          initialPosition: pos,
          initialTitle: title,
        ),
      ),
    );
    if (res == MarkEditResult.saved && mark == null) {
      // новая метка сохранена: точка выбора больше не нужна
      await _clearPick();
      _snack('Метка сохранена');
    }
  }

  Future<void> _openMarks() async {
    final store = _marks;
    if (store == null) return;
    final m = await Navigator.of(context).push<Mark>(
      MaterialPageRoute<Mark>(builder: (_) => MarksScreen(store: store)),
    );
    if (m != null) await _flyTo(m.position, zoom: 17);
  }

  /// Нажатие по карте: если попали в метку — открываем её.
  Future<bool> _tapMark(math.Point<double> point) async {
    final store = _marks;
    final c = _map;
    if (store == null || c == null) return false;
    try {
      final hits = await c.queryRenderedFeatures(point, ['marks-dot'], null);
      for (final f in hits) {
        final props = (f is Map ? f['properties'] : null);
        final raw = props is Map ? props['id'] : null;
        final id = raw is num ? raw.toInt() : int.tryParse('$raw');
        final m = id == null ? null : store.byId(id);
        if (m != null) {
          await _editMark(mark: m);
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  void _pushPeers() {
    _setSrc(
      OverlayIds.peers,
      _fc([
        for (final peer in widget.markers.peers)
          _pt(peer.position, {'name': peer.nodeId}),
      ]),
    );
  }

  // --------------------------------------------------------------- камера

  Future<void> _flyTo(ll.LatLng pos, {double zoom = 16}) async {
    if (!pos.latitude.isFinite || !pos.longitude.isFinite) return;
    try {
      await _map?.animateCamera(
        CameraUpdate.newLatLngZoom(LatLng(pos.latitude, pos.longitude), zoom),
        duration: const Duration(milliseconds: 700),
      );
    } catch (_) {}
  }

  Future<void> _toggleTilt() async {
    final target = _pitch > 5 ? 0.0 : 60.0;
    try {
      if (_track != MyLocationTrackingMode.none) {
        await _map?.setTrackingCameraOptions(
          tilt: math.min(target, 60),
          duration: const Duration(milliseconds: 400),
        );
      } else {
        await _map?.animateCamera(
          CameraUpdate.tiltTo(target),
          duration: const Duration(milliseconds: 400),
        );
      }
    } catch (_) {}
  }

  Future<void> _resetNorth() async {
    await _map?.animateCamera(
      CameraUpdate.bearingTo(0),
      duration: const Duration(milliseconds: 400),
    );
  }

  Future<void> _cycleTracking() async {
    if (!_locGranted) {
      await _initLocation();
      return;
    }
    final me = _me;
    switch (_track) {
      case MyLocationTrackingMode.none:
        if (me != null) await _flyTo(me, zoom: 16.5);
        setState(() => _track = MyLocationTrackingMode.tracking);
      case MyLocationTrackingMode.tracking:
        setState(() => _track = MyLocationTrackingMode.trackingGps);
        await Future<void>.delayed(const Duration(milliseconds: 500));
        try {
          await _map?.setTrackingCameraOptions(tilt: 45);
        } catch (_) {}
      default:
        setState(() => _track = MyLocationTrackingMode.none);
    }
  }

  // ---------------------------------------------------------------- поиск

  void _onQuery(String v) {
    _debounce?.cancel();
    if (v.trim().length < 2) {
      setState(() {
        _results = const [];
        _searching = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 350), () async {
      final svc = _search;
      if (!mounted || svc == null) return;
      setState(() => _searching = true);
      try {
        final off = await svc.searchOffline(v);
        if (!mounted || _query.text != v) return;
        setState(() => _results = off);
        final on = await svc.searchOnline(v);
        if (!mounted || _query.text != v) return;
        setState(() => _results = [...off, ...on]);
      } catch (e) {
        debugPrint('поиск: $e');
      } finally {
        if (mounted && _query.text == v) setState(() => _searching = false);
      }
    });
  }

  Future<void> _pick(PlaceResult r, {bool fly = true}) async {
    _focus.unfocus();
    setState(() {
      _picked = r;
      _results = const [];
      _searching = false;
    });
    await _pushPick();
    if (fly) await _flyTo(r.position);
  }

  Future<void> _clearPick() async {
    setState(() => _picked = null);
    await _pushPick();
  }

  // ----------------------------------------------------------- навигация

  Future<void> _startNav(TravelMode mode) async {
    final dest = _picked;
    final me = _me;
    if (dest == null) return;
    if (me == null) {
      _snack('Нет GPS-фикса. Выйдите на открытое место и подождите.');
      return;
    }
    setState(() => _routing_ = true);
    final route = await _routing.route(me, dest.position, mode);
    if (!mounted) return;
    setState(() => _routing_ = false);

    _nav.start(destination: dest.position, name: dest.name, mode: mode, route: route);
    _nav.updatePosition(me);
    await _clearPick();
    await _pushRoute();
    if (!route.byRoads) {
      _snack('Нет сети: показана прямая линия и направление на цель.');
    }
    await _flyTo(me, zoom: 17);
    setState(() => _track = MyLocationTrackingMode.trackingGps);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    try {
      await _map?.setTrackingCameraOptions(tilt: 45);
    } catch (_) {}
  }

  Future<void> _reroute() async {
    final me = _me;
    final dest = _nav.destination;
    if (_rerouting || me == null || dest == null) return;
    _rerouting = true;
    try {
      final r = await _routing.route(me, dest, _nav.mode);
      if (_nav.destination != null) {
        _nav.replaceRoute(r);
        await _pushRoute();
      }
    } finally {
      _rerouting = false;
    }
  }

  Future<void> _stopNav() async {
    _nav.stop();
    await _pushRoute();
    setState(() => _track = MyLocationTrackingMode.tracking);
    try {
      await _map?.setTrackingCameraOptions(tilt: 0);
      await _resetNorth();
    } catch (_) {}
  }

  void _onNav() {
    if (_nav.arrived && _nav.active) {
      _snack('Вы прибыли: ${_nav.destinationName}');
      _stopNav();
    }
  }

  // ------------------------------------------------------------------ mesh

  Future<void> _copyPosition(ll.LatLng pos) async {
    final text = formatCoord(pos, widget.settings.coordFormat);
    await Clipboard.setData(ClipboardData(text: text));
    if (widget.settings.haptics) HapticFeedback.selectionClick();
    _snack('Скопировано: $text');
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    widget.settings.removeListener(_onSettings);
    WakelockPlus.disable();
    _debounce?.cancel();
    _packs?.removeListener(_onPacksChanged);
    widget.markers.removeListener(_pushPeers);
    _nav.removeListener(_onNav);
    _search?.dispose();
    _marks?.removeListener(_pushMarks);
    _marks?.dispose();
    _packs?.dispose();
    _nav.dispose();
    _query.dispose();
    _focus.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------------- UI

  @override
  Widget build(BuildContext context) {
    if (_stylePath == null) {
      return Scaffold(
        body: Center(
          child: _error != null
              ? Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_error!, textAlign: TextAlign.center),
                )
              : const CircularProgressIndicator(),
        ),
      );
    }

    final dark = _theme == MapTheme.dark;
    return Scaffold(
      // Клавиатура не должна менять размер карты: иначе нативный вид MapLibre
      // пересоздаётся (чёрный экран и вылет при открытии поиска).
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          MapLibreMap(
            styleString: _stylePath!,
            initialCameraPosition: CameraPosition(
              target: widget.settings.lastLat == null
                  ? _alicante
                  : LatLng(widget.settings.lastLat!, widget.settings.lastLon!),
              zoom: widget.settings.lastZoom ?? 11,
            ),
            onCameraIdle: () {
              try {
                final cp = _map?.cameraPosition;
                if (cp != null) {
                  widget.settings.saveCamera(cp.target.latitude, cp.target.longitude, cp.zoom);
                }
              } catch (_) {}
            },
            minMaxZoomPreference: const MinMaxZoomPreference(2, 20),
            compassEnabled: false,
            rotateGesturesEnabled: true,
            tiltGesturesEnabled: true,
            trackCameraPosition: true,
            myLocationEnabled: _locGranted,
            myLocationTrackingMode: _track,
            myLocationRenderMode: _track == MyLocationTrackingMode.none
                ? MyLocationRenderMode.normal
                : MyLocationRenderMode.compass,
            onMapCreated: (c) => _map = c,
            onStyleLoadedCallback: _onStyleLoaded,
            onUserLocationUpdated: (loc) {
              final pos = ll.LatLng(loc.position.latitude, loc.position.longitude);
              _me = pos;
              _nav.updatePosition(pos);
            },
            onCameraTrackingDismissed: () {
              if (mounted) setState(() => _track = MyLocationTrackingMode.none);
            },
            onCameraTrackingChanged: (m) {
              if (mounted) setState(() => _track = m);
            },
            onCameraMove: (cam) {
              if ((cam.bearing - _bearing).abs() > 1 || (cam.tilt - _pitch).abs() > 1) {
                setState(() {
                  _bearing = cam.bearing;
                  _pitch = cam.tilt;
                });
              }
            },
            onMapClick: (point, _) async {
              _focus.unfocus();
              if (_results.isNotEmpty) setState(() => _results = const []);
              await _tapMark(point);
            },
            onMapLongClick: (_, c) {
              final pos = ll.LatLng(c.latitude, c.longitude);
              _pick(
                PlaceResult(
                  name: 'Выбранная точка',
                  subtitle: '${pos.latitude.toStringAsFixed(5)}, '
                      '${pos.longitude.toStringAsFixed(5)}',
                  position: pos,
                  offline: true,
                ),
                fly: false,
              );
            },
          ),
          SafeArea(
            child: Stack(
              children: [
                Positioned(top: 8, left: 8, right: 8, child: _topArea(dark)),
                Positioned(right: 8, top: 76, child: _sideButtons()),
                Positioned(top: 76, left: 8, right: 72, child: _downloadBanner()),
                Positioned(left: 8, right: 8, bottom: 8, child: _bottomArea()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _topArea(bool dark) {
    return ListenableBuilder(
      listenable: _nav,
      builder: (context, _) {
        if (_nav.active) return _navBanner();
        return Column(
          children: [
            Material(
              elevation: 4,
              borderRadius: BorderRadius.circular(28),
              child: TextField(
                controller: _query,
                focusNode: _focus,
                onChanged: _onQuery,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Поиск места или адреса',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searching
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      : (_query.text.isEmpty
                          ? null
                          : IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: () {
                                _query.clear();
                                _onQuery('');
                              },
                            )),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            if (_results.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(top: 6),
                constraints: const BoxConstraints(maxHeight: 320),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [BoxShadow(blurRadius: 6, color: Colors.black26)],
                ),
                child: ListView.separated(
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  itemCount: _results.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final r = _results[i];
                    return ListTile(
                      dense: true,
                      leading: Icon(
                        r.offline ? Icons.offline_pin : Icons.public,
                        color: r.offline ? Colors.green : null,
                      ),
                      title: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: r.subtitle.isEmpty
                          ? null
                          : Text(r.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => _pick(r),
                    );
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _navBanner() {
    final step = _nav.nextStep;
    final byRoads = _nav.route?.byRoads ?? false;
    return Card(
      color: Theme.of(context).colorScheme.primaryContainer,
      elevation: 6,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Transform.rotate(
              angle: ((_nav.bearingToTarget - _bearing) * math.pi / 180),
              child: const Icon(Icons.navigation, size: 36),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    byRoads ? (step?.text ?? 'Продолжайте движение') : 'Прямая линия к цели',
                    style: Theme.of(context).textTheme.titleMedium,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (byRoads && step != null)
                    Text('через ${NavigationController.formatDistance(_nav.distToNextStepM)}'),
                  if (!byRoads) const Text('Нет сети: маршрут по дорогам недоступен'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sideButtons() {
    Widget btn(IconData icon, String tip, VoidCallback onTap, {Color? color}) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: FloatingActionButton.small(
          heroTag: tip,
          tooltip: tip,
          backgroundColor: color,
          onPressed: onTap,
          child: Icon(icon),
        ),
      );
    }

    return Column(
      children: [
        btn(Icons.layers, 'Слои и тема', _openLayers),
        btn(Icons.bookmarks, 'Мои метки', _openMarks),
        btn(Icons.settings, 'Настройки', () async {
          await Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => SettingsScreen(
                settings: widget.settings,
                packs: _packs,
                marks: _marks,
              ),
            ),
          );
        }),
        btn(Icons.satellite_alt, 'Скачать спутник области', _openSatDownload),
        btn(Icons.download_for_offline, 'Офлайн-карты', () async {
          await Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => PacksScreen(packs: _packs!)),
          );
        }),
        btn(
          Icons.view_in_ar,
          '3D-наклон',
          _toggleTilt,
          color: _pitch > 5 ? Theme.of(context).colorScheme.primaryContainer : null,
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: FloatingActionButton.small(
            heroTag: 'north',
            tooltip: 'Север',
            onPressed: _resetNorth,
            child: Transform.rotate(
              angle: -_bearing * math.pi / 180,
              child: const Icon(Icons.explore),
            ),
          ),
        ),
      ],
    );
  }

  Widget _bottomArea() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        FloatingActionButton.small(
          heroTag: 'send',
          tooltip: 'Копировать мои координаты',
          onPressed: _me == null ? null : () => _copyPosition(_me!),
          child: const Icon(Icons.copy),
        ),
        const SizedBox(height: 8),
        FloatingActionButton(
          heroTag: 'me',
          tooltip: 'Моё местоположение',
          onPressed: _cycleTracking,
          child: Icon(switch (_track) {
            MyLocationTrackingMode.none => Icons.my_location,
            MyLocationTrackingMode.tracking => Icons.gps_fixed,
            _ => Icons.navigation,
          }),
        ),
        const SizedBox(height: 8),
        ListenableBuilder(
          listenable: _nav,
          builder: (context, _) {
            if (_nav.active) return _navSummary();
            if (_picked != null) return _placeCard(_picked!);
            return const SizedBox.shrink();
          },
        ),
      ],
    );
  }

  Widget _navSummary() {
    return SizedBox(
      width: double.infinity,
      child: Card(
        elevation: 6,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _nav.destinationName,
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${NavigationController.formatDistance(_nav.remainingM)}'
                      ' · ${NavigationController.formatDuration(_nav.remainingS)}'
                      ' · ${_nav.mode.title}',
                    ),
                  ],
                ),
              ),
              FilledButton.tonalIcon(
                onPressed: _stopNav,
                icon: const Icon(Icons.stop),
                label: const Text('Стоп'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeCard(PlaceResult r) {
    return SizedBox(
      width: double.infinity,
      child: Card(
        elevation: 6,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      r.name,
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.close), onPressed: _clearPick),
                ],
              ),
              if (r.subtitle.isNotEmpty)
                Text(r.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
              Text(
                '${r.position.latitude.toStringAsFixed(5)}, '
                '${r.position.longitude.toStringAsFixed(5)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              if (_routing_)
                const LinearProgressIndicator()
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    FilledButton.icon(
                      onPressed: () => _startNav(TravelMode.foot),
                      icon: const Icon(Icons.directions_walk),
                      label: const Text('Пешком'),
                    ),
                    FilledButton.icon(
                      onPressed: () => _startNav(TravelMode.car),
                      icon: const Icon(Icons.directions_car),
                      label: const Text('На машине'),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: () => _editMark(
                        pos: r.position,
                        title: r.name == 'Выбранная точка' ? '' : r.name,
                      ),
                      icon: const Icon(Icons.bookmark_add),
                      label: const Text('Сохранить метку'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => _copyPosition(r.position),
                      icon: const Icon(Icons.copy),
                      label: const Text('Копировать'),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _downloadBanner() {
    final packs = _packs;
    if (packs == null) return const SizedBox.shrink();
    return ListenableBuilder(
      listenable: packs,
      builder: (context, _) {
        final jobs = packs.satJobs;
        if (jobs.isEmpty) return const SizedBox.shrink();
        return Column(
          children: [
            for (final e in jobs.entries)
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
                  child: packs.progress.containsKey(e.key)
                      ? Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${e.value}: ${((packs.progress[e.key] ?? 0) * 100).round()}%',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  LinearProgressIndicator(value: packs.progress[e.key]),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close),
                              tooltip: 'Отменить',
                              onPressed: () => packs.cancel(e.key),
                            ),
                          ],
                        )
                      : Row(
                          children: [
                            Expanded(
                              child: Text(
                                packs.errorOf(e.key) ?? '',
                                style: TextStyle(color: Theme.of(context).colorScheme.error),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: () => packs.dismissError(e.key),
                            ),
                          ],
                        ),
                ),
              ),
          ],
        );
      },
    );
  }

  Future<void> _openSatDownload() async {
    final map = _map;
    if (map == null || _packs == null) return;
    final LatLngBounds b;
    try {
      b = await map.getVisibleRegion();
    } catch (_) {
      _snack('Карта ещё не готова');
      return;
    }
    // Видимая область экрана и выбранная готовая область (регион).
    final vWest = b.southwest.longitude;
    final vSouth = b.southwest.latitude;
    final vEast = b.northeast.longitude;
    final vNorth = b.northeast.latitude;
    var west = vWest, south = vSouth, east = vEast, north = vNorth;
    var cLat = (south + north) / 2;
    var cLon = (west + east) / 2;
    SatRegion? region;

    final visibleName =
        'Спутник ${cLat.toStringAsFixed(2)}, ${cLon.toStringAsFixed(2)}';
    var provider = SatProvider.autoFor(cLat, cLon);
    var maxZ = provider == SatProvider.pnoa ? 18 : 12;
    final nameCtl = TextEditingController(text: visibleName);

    void applyRegion(SatRegion? r) {
      region = r;
      if (r == null) {
        west = vWest;
        south = vSouth;
        east = vEast;
        north = vNorth;
      } else {
        west = r.west;
        south = r.south;
        east = r.east;
        north = r.north;
      }
      cLat = (south + north) / 2;
      cLon = (west + east) / 2;
      provider = (r?.pnoaZoom != null) ? SatProvider.pnoa : SatProvider.autoFor(cLat, cLon);
      maxZ = provider == SatProvider.pnoa ? (r?.pnoaZoom ?? 18) : (r?.eoxZoom ?? 12);
      nameCtl.text = r?.title ?? visibleName;
    }

    if (!mounted) return;
    final job = await showModalBottomSheet<SatelliteJob>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          // Для готовой области id постоянный: повторный запуск продолжит прерванную загрузку.
          String jobId() => region == null
              ? 'sat_${DateTime.now().millisecondsSinceEpoch}'
              : 'sat_r${SatRegion.presets.indexOf(region!)}_${provider.name}_z$maxZ';
          SatelliteJob make() => SatelliteJob(
                id: jobId(),
                title: nameCtl.text.trim().isEmpty ? 'Спутник' : nameCtl.text.trim(),
                provider: provider,
                west: west,
                south: south,
                east: east,
                north: north,
                minZoom: math.min(provider == SatProvider.pnoa ? 8 : 3, maxZ),
                maxZoom: maxZ,
              );
          final est = SatelliteDownloader.estimate(make());
          final tooBig = est.tiles > SatelliteDownloader.maxTiles;
          final mpp = 156543.03 * math.cos(cLat * math.pi / 180) / (1 << maxZ);
          final outsideSpain =
              provider == SatProvider.pnoa && !SatProvider.inSpain(cLat, cLon);

          return Padding(
            padding: EdgeInsets.fromLTRB(
              16,
              16,
              16,
              16 + MediaQuery.of(ctx).viewInsets.bottom,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Скачать спутник для офлайна',
                    style: Theme.of(ctx).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  const SizedBox(height: 4),
                  DropdownButton<SatRegion?>(
                    isExpanded: true,
                    value: region,
                    items: [
                      const DropdownMenuItem<SatRegion?>(
                        value: null,
                        child: Text('Видимая область на экране'),
                      ),
                      for (final r in SatRegion.presets)
                        DropdownMenuItem<SatRegion?>(value: r, child: Text(r.title)),
                    ],
                    onChanged: (r) => setSheet(() => applyRegion(r)),
                  ),
                  TextField(
                    controller: nameCtl,
                    decoration: const InputDecoration(labelText: 'Название'),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final pv in SatProvider.values)
                        ChoiceChip(
                          label: Text(
                            pv.shortTitle,
                          ),
                          selected: provider == pv,
                          onSelected: (_) => setSheet(() {
                            provider = pv;
                            maxZ = pv == SatProvider.pnoa
                                ? (region?.pnoaZoom ?? 18)
                                : (region?.eoxZoom ?? 12);
                          }),
                        ),
                    ],
                  ),
                  Text(provider.title, style: Theme.of(ctx).textTheme.bodySmall),
                  const SizedBox(height: 8),
                  Text('Детализация: до z$maxZ (≈ ${mpp.toStringAsFixed(2)} м/пиксель)'),
                  Slider(
                    min: provider.minSlider.toDouble(),
                    max: provider.maxZoom.toDouble(),
                    divisions: provider.maxZoom - provider.minSlider,
                    value: maxZ
                        .toDouble()
                        .clamp(provider.minSlider.toDouble(), provider.maxZoom.toDouble()),
                    label: 'z$maxZ',
                    onChanged: (v) => setSheet(() => maxZ = v.round()),
                  ),
                  Text(
                    '≈ ${est.tiles} тайлов, ≈ ${est.megabytes} МБ',
                    style: Theme.of(ctx).textTheme.titleSmall,
                  ),
                  if (est.megabytes > 1024 && !tooBig)
                    Text(
                      'Это ≈ ${(est.megabytes / 1024).toStringAsFixed(1)} ГБ. '
                      'Проверьте, что в телефоне достаточно свободного места.',
                    ),
                  if (tooBig)
                    Text(
                      'Слишком много тайлов. Уменьшите детализацию или выберите область поменьше.',
                      style: TextStyle(color: Theme.of(ctx).colorScheme.error),
                    ),
                  if (outsideSpain)
                    Text(
                      'Снимков PNOA вне Испании нет.',
                      style: TextStyle(color: Theme.of(ctx).colorScheme.error),
                    ),
                  const SizedBox(height: 4),
                  Text(provider.attribution, style: Theme.of(ctx).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  const Text(
                    'Не сворачивайте и не закрывайте приложение, пока идёт загрузка. '
                    'Нужен интернет (лучше Wi-Fi).',
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: (tooBig || outsideSpain)
                          ? null
                          : () => Navigator.pop(ctx, make()),
                      icon: const Icon(Icons.download),
                      label: const Text('Скачать'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    nameCtl.dispose();
    if (job == null || !mounted) return;
    _snack('Загрузка началась. После неё включите тему «Спутник».');
    await _packs!.downloadSatellite(job);
  }

  void _openLayers() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Тема карты', style: Theme.of(ctx).textTheme.titleMedium),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final t in MapTheme.values)
                      ChoiceChip(
                        label: Text(t.title),
                        selected: _theme == t,
                        onSelected: (_) {
                          widget.settings.update(() => widget.settings.mapTheme = t);
                          setSheet(() {});
                        },
                      ),
                  ],
                ),
                if (_theme == MapTheme.satellite)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'Онлайн снимки Esri видны с интернетом. Без сети остаётся '
                      'встроенный обзор мира и скачанные области.',
                    ),
                  ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('3D-здания'),
                  subtitle: const Text('Наклоните карту двумя пальцами или кнопкой'),
                  value: _buildings3d,
                  onChanged: (v) {
                    widget.settings.update(() => widget.settings.buildings3d = v);
                    setSheet(() {});
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Рельеф (тени гор)'),
                  subtitle: const Text('Данные высот из интернета, офлайн только кэш'),
                  value: _relief,
                  onChanged: (v) {
                    widget.settings.update(() => widget.settings.relief = v);
                    setSheet(() {});
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
