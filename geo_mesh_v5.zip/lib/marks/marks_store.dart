import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'mark.dart';

/// Хранилище меток (SQLite) + копии фото во внутренней папке приложения.
/// Всё локально, работает без сети.
class MarksStore extends ChangeNotifier {
  MarksStore._(this._db, this.photoDir);

  final Database _db;
  final String photoDir;
  List<Mark> _marks = const [];

  List<Mark> get marks => _marks;

  Mark? byId(int id) {
    for (final m in _marks) {
      if (m.id == id) return m;
    }
    return null;
  }

  static Future<MarksStore> open() async {
    final support = await getApplicationSupportDirectory();
    final photoDir = p.join(support.path, 'mark_photos');
    await Directory(photoDir).create(recursive: true);
    final db = await openDatabase(
      p.join(support.path, 'marks.db'),
      version: 1,
      onCreate: (db, _) => db.execute('''
        CREATE TABLE marks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          note TEXT NOT NULL DEFAULT '',
          lat REAL NOT NULL,
          lon REAL NOT NULL,
          photos TEXT NOT NULL DEFAULT '[]',
          created_ms INTEGER NOT NULL
        )
      '''),
    );
    final store = MarksStore._(db, photoDir);
    await store._reload();
    return store;
  }

  Future<void> _reload() async {
    final rows = await _db.query('marks', orderBy: 'created_ms DESC');
    _marks = rows.map(Mark.fromRow).toList(growable: false);
    notifyListeners();
  }

  /// Сохраняет новую метку или обновляет существующую.
  Future<Mark> save(Mark m) async {
    if (m.id == null) {
      m.id = await _db.insert('marks', m.toRow());
    } else {
      await _db.update('marks', m.toRow(), where: 'id = ?', whereArgs: [m.id]);
    }
    await _reload();
    return m;
  }

  Future<void> delete(Mark m) async {
    if (m.id != null) {
      await _db.delete('marks', where: 'id = ?', whereArgs: [m.id]);
    }
    for (final path in m.photos) {
      await deletePhotoFile(path);
    }
    await _reload();
  }

  /// Копирует выбранное фото в папку приложения (оригинал в галерее
  /// не трогаем) и возвращает путь копии.
  Future<String> importPhoto(String sourcePath) async {
    final ext = p.extension(sourcePath).isEmpty ? '.jpg' : p.extension(sourcePath);
    final name = '${DateTime.now().microsecondsSinceEpoch}$ext';
    final target = p.join(photoDir, name);
    await File(sourcePath).copy(target);
    return target;
  }

  Future<void> deletePhotoFile(String path) async {
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  @override
  void dispose() {
    _db.close();
    super.dispose();
  }
}
