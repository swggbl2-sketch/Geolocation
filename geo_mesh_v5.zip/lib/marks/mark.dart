import 'dart:convert';

import 'package:latlong2/latlong.dart';

/// Пользовательская метка: координаты, подпись, описание и фото.
class Mark {
  Mark({
    this.id,
    required this.title,
    required this.position,
    this.note = '',
    List<String>? photos,
    DateTime? created,
  })  : photos = photos ?? <String>[],
        created = created ?? DateTime.now();

  int? id;
  String title;
  LatLng position;
  String note;

  /// Пути к копиям фото в папке приложения.
  List<String> photos;
  DateTime created;

  Map<String, Object?> toRow() => {
        if (id != null) 'id': id,
        'title': title,
        'note': note,
        'lat': position.latitude,
        'lon': position.longitude,
        'photos': jsonEncode(photos),
        'created_ms': created.millisecondsSinceEpoch,
      };

  static Mark fromRow(Map<String, Object?> r) {
    List<String> photos = const [];
    try {
      photos = (jsonDecode('${r['photos'] ?? '[]'}') as List).cast<String>();
    } catch (_) {}
    return Mark(
      id: (r['id'] as num).toInt(),
      title: '${r['title'] ?? ''}',
      note: '${r['note'] ?? ''}',
      position: LatLng((r['lat'] as num).toDouble(), (r['lon'] as num).toDouble()),
      photos: List<String>.of(photos),
      created: DateTime.fromMillisecondsSinceEpoch(
        (r['created_ms'] as num?)?.toInt() ?? 0,
      ),
    );
  }
}
