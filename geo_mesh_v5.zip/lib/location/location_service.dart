
import 'package:geolocator/geolocator.dart';

class LocationException implements Exception {
  const LocationException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Обёртка над geolocator: проверка прав + поток позиций в реальном времени.
/// GPS работает без интернета.
class LocationService {
  Future<void> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const LocationException('GPS выключен. Включите геолокацию.');
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationException('Нет разрешения на геолокацию.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Геолокация запрещена навсегда. Разрешите её в настройках приложения.',
      );
    }
  }

  /// Позиции приходят, когда пользователь сместился на [distanceFilterMeters].
  Stream<Position> positionStream({int distanceFilterMeters = 3}) async* {
    await ensurePermission();
    yield* Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: distanceFilterMeters,
      ),
    );
  }
}
