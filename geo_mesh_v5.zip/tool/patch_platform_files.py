#!/usr/bin/env python3
"""Донастраивает сгенерированные `flutter create` файлы платформ.

Запуск из корня проекта, ПОСЛЕ `flutter create --platforms=android,ios .`:
    python3 tool/patch_platform_files.py
Скрипт идемпотентный: повторный запуск ничего не дублирует.

Android: разрешения (геолокация, интернет для скачивания карт) и minSdk 24
         (минимум для MapLibre).
iOS:     описания доступа к геолокации, фото и камере (метки с фото).
"""
import pathlib
import re
import sys

ANDROID_MANIFEST = pathlib.Path("android/app/src/main/AndroidManifest.xml")
ANDROID_GRADLE = [
    pathlib.Path("android/app/build.gradle.kts"),
    pathlib.Path("android/app/build.gradle"),
]
IOS = pathlib.Path("ios/Runner/Info.plist")

PERMS = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
]


def patch_manifest():
    if not ANDROID_MANIFEST.exists():
        print("android: манифест не найден, пропускаю")
        return
    text = ANDROID_MANIFEST.read_text(encoding="utf-8")
    add = "".join(
        f'    <uses-permission android:name="{p}" />\n'
        for p in PERMS
        if f'"{p}"' not in text
    )
    if not add:
        print("android: разрешения уже есть")
        return
    idx = text.index("<application")
    ANDROID_MANIFEST.write_text(
        text[:idx] + add.lstrip() + "    " + text[idx:], encoding="utf-8"
    )
    print("android: разрешения добавлены")


def patch_gradle():
    for path in ANDROID_GRADLE:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        new = re.sub(
            r"minSdk(?:Version)?\s*=?\s*flutter\.minSdkVersion",
            "minSdk = 24" if path.suffix == ".kts" else "minSdkVersion 24",
            text,
        )
        if new != text:
            path.write_text(new, encoding="utf-8")
            print(f"android: minSdk 24 в {path.name}")
        else:
            print(f"android: minSdk в {path.name} не менялся")
        return
    print("android: build.gradle не найден, пропускаю")


IOS_KEYS = {
    "NSLocationWhenInUseUsageDescription":
        "Нужна геолокация для показа вашей позиции на карте",
    "NSPhotoLibraryUsageDescription":
        "Нужен доступ к фото, чтобы прикреплять их к меткам",
    "NSCameraUsageDescription":
        "Нужна камера, чтобы снимать фото для меток",
}


def patch_ios():
    if not IOS.exists():
        print("ios: Info.plist не найден, пропускаю")
        return
    text = IOS.read_text(encoding="utf-8")
    add = "".join(
        f"\t<key>{k}</key>\n\t<string>{v}</string>\n"
        for k, v in IOS_KEYS.items()
        if k not in text
    )
    if not add:
        print("ios: ключи уже есть")
        return
    idx = text.rindex("</dict>")
    IOS.write_text(text[:idx] + add + text[idx:], encoding="utf-8")
    print("ios: ключи добавлены")


if __name__ == "__main__":
    patch_manifest()
    patch_gradle()
    patch_ios()
    sys.exit(0)
