#!/usr/bin/env python3
"""Каталог офлайн-пакетов: единственный источник правды.

Из него генерируются:
  tool/packs.json              список для workflow build-packs (матрица сборки)
  lib/packs/catalog_data.dart  каталог внутри приложения

Запуск из корня проекта:   python3 tool/packs_def.py

Поля записи:
  id       имя пакета; тег релиза `pack-<id>`, файл `<id>.mbtiles`
  title    название в приложении (по-русски)
  group    id страны, если страна разбита на части (иначе None)
  gf       путь выгрузки Geofabrik без `-latest.osm.pbf`, например europe/spain/valencia
  bounds   необязательно: minlon,minlat,maxlon,maxlat, ограничить область
  pbf      размер исходной выгрузки, МБ (для оценки размера пакета)
  share    доля от pbf, если берём только часть области (bounds)

Размер готового пакета (zoom до 14, OpenMapTiles) ≈ 1.3 × размер .osm.pbf.
Файл в Releases не может быть больше 2 ГБ: workflow режет такие пакеты на части
по 1900 МБ, приложение склеивает их при скачивании.
"""
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent

# (id, название, путь Geofabrik, размер pbf МБ)
WHOLE = [
    ("albania", "Албания", "europe/albania", 53),
    ("andorra", "Андорра", "europe/andorra", 3),
    ("armenia", "Армения", "asia/armenia", 52),
    ("austria", "Австрия", "europe/austria", 811),
    ("azerbaijan", "Азербайджан", "asia/azerbaijan", 46),
    ("azores", "Азорские острова", "europe/azores", 18),
    ("belarus", "Беларусь", "europe/belarus", 349),
    ("belgium", "Бельгия", "europe/belgium", 695),
    ("bosnia-herzegovina", "Босния и Герцеговина", "europe/bosnia-herzegovina", 160),
    ("bulgaria", "Болгария", "europe/bulgaria", 174),
    ("croatia", "Хорватия", "europe/croatia", 199),
    ("cyprus", "Кипр", "europe/cyprus", 38),
    ("czech-republic", "Чехия", "europe/czech-republic", 948),
    ("denmark", "Дания", "europe/denmark", 495),
    ("estonia", "Эстония", "europe/estonia", 123),
    ("faroe-islands", "Фарерские острова", "europe/faroe-islands", 8),
    ("finland", "Финляндия", "europe/finland", 769),
    ("georgia", "Грузия", "europe/georgia", 102),
    ("greece", "Греция", "europe/greece", 341),
    ("guernsey-jersey", "Гернси и Джерси", "europe/guernsey-jersey", 4),
    ("hungary", "Венгрия", "europe/hungary", 325),
    ("iceland", "Исландия", "europe/iceland", 70),
    ("ireland-and-northern-ireland", "Ирландия и Северная Ирландия",
     "europe/ireland-and-northern-ireland", 413),
    ("isle-of-man", "Остров Мэн", "europe/isle-of-man", 6),
    ("kosovo", "Косово", "europe/kosovo", 31),
    ("latvia", "Латвия", "europe/latvia", 141),
    ("liechtenstein", "Лихтенштейн", "europe/liechtenstein", 3),
    ("lithuania", "Литва", "europe/lithuania", 222),
    ("luxembourg", "Люксембург", "europe/luxembourg", 55),
    ("macedonia", "Северная Македония", "europe/macedonia", 30),
    ("malta", "Мальта", "europe/malta", 9),
    ("moldova", "Молдова", "europe/moldova", 101),
    ("monaco", "Монако", "europe/monaco", 1),
    ("montenegro", "Черногория", "europe/montenegro", 34),
    ("netherlands", "Нидерланды", "europe/netherlands", 1396),
    ("norway", "Норвегия", "europe/norway", 1396),
    ("portugal", "Португалия", "europe/portugal", 424),
    ("romania", "Румыния", "europe/romania", 329),
    ("serbia", "Сербия", "europe/serbia", 240),
    ("slovakia", "Словакия", "europe/slovakia", 345),
    ("slovenia", "Словения", "europe/slovenia", 312),
    ("sweden", "Швеция", "europe/sweden", 835),
    ("switzerland", "Швейцария", "europe/switzerland", 546),
    ("turkey", "Турция", "europe/turkey", 650),
    ("ukraine", "Украина", "europe/ukraine", 700),
]

# Страны, разбитые на части: group -> (название страны, [(id, название, путь, pbf МБ)])
SPLIT = {
    "germany": (
        "Германия",
        [
            ("germany-baden-wuerttemberg", "Баден-Вюртемберг", "europe/germany/baden-wuerttemberg", 650),
            ("germany-bayern", "Бавария", "europe/germany/bayern", 852),
            ("germany-berlin", "Берлин", "europe/germany/berlin", 99),
            ("germany-brandenburg", "Бранденбург", "europe/germany/brandenburg", 295),
            ("germany-bremen", "Бремен", "europe/germany/bremen", 21),
            ("germany-hamburg", "Гамбург", "europe/germany/hamburg", 53),
            ("germany-hessen", "Гессен", "europe/germany/hessen", 345),
            ("germany-mecklenburg-vorpommern", "Мекленбург — Передняя Померания",
             "europe/germany/mecklenburg-vorpommern", 128),
            ("germany-niedersachsen", "Нижняя Саксония", "europe/germany/niedersachsen", 506),
            ("germany-nordrhein-westfalen", "Северный Рейн — Вестфалия",
             "europe/germany/nordrhein-westfalen", 913),
            ("germany-rheinland-pfalz", "Рейнланд-Пфальц", "europe/germany/rheinland-pfalz", 271),
            ("germany-saarland", "Саар", "europe/germany/saarland", 55),
            ("germany-sachsen", "Саксония", "europe/germany/sachsen", 269),
            ("germany-sachsen-anhalt", "Саксония-Анхальт", "europe/germany/sachsen-anhalt", 175),
            ("germany-schleswig-holstein", "Шлезвиг-Гольштейн", "europe/germany/schleswig-holstein", 158),
            ("germany-thueringen", "Тюрингия", "europe/germany/thueringen", 159),
        ],
    ),
    "france": (
        "Франция",
        [
            ("france-alsace", "Эльзас", "europe/france/alsace", 131),
            ("france-aquitaine", "Аквитания", "europe/france/aquitaine", 296),
            ("france-auvergne", "Овернь", "europe/france/auvergne", 155),
            ("france-basse-normandie", "Нижняя Нормандия", "europe/france/basse-normandie", 144),
            ("france-bourgogne", "Бургундия", "europe/france/bourgogne", 199),
            ("france-bretagne", "Бретань", "europe/france/bretagne", 329),
            ("france-centre", "Центр — Долина Луары", "europe/france/centre", 243),
            ("france-champagne-ardenne", "Шампань — Арденны", "europe/france/champagne-ardenne", 105),
            ("france-corse", "Корсика", "europe/france/corse", 34),
            ("france-franche-comte", "Франш-Конте", "europe/france/franche-comte", 124),
            ("france-haute-normandie", "Верхняя Нормандия", "europe/france/haute-normandie", 106),
            ("france-ile-de-france", "Иль-де-Франс (Париж)", "europe/france/ile-de-france", 339),
            ("france-languedoc-roussillon", "Лангедок — Руссильон", "europe/france/languedoc-roussillon", 269),
            ("france-limousin", "Лимузен", "europe/france/limousin", 99),
            ("france-lorraine", "Лотарингия", "europe/france/lorraine", 171),
            ("france-midi-pyrenees", "Юг — Пиренеи", "europe/france/midi-pyrenees", 362),
            ("france-nord-pas-de-calais", "Нор — Па-де-Кале", "europe/france/nord-pas-de-calais", 239),
            ("france-pays-de-la-loire", "Земли Луары", "europe/france/pays-de-la-loire", 372),
            ("france-picardie", "Пикардия", "europe/france/picardie", 133),
            ("france-poitou-charentes", "Пуату — Шаранта", "europe/france/poitou-charentes", 150),
            ("france-provence-alpes-cote-d-azur", "Прованс — Лазурный берег",
             "europe/france/provence-alpes-cote-d-azur", 389),
            ("france-rhone-alpes", "Рона — Альпы", "europe/france/rhone-alpes", 530),
        ],
    ),
    "italy": (
        "Италия",
        [
            ("italy-nord-ovest", "Северо-запад (Милан, Турин, Генуя)", "europe/italy/nord-ovest", 591),
            ("italy-nord-est", "Северо-восток (Венеция, Болонья)", "europe/italy/nord-est", 624),
            ("italy-centro", "Центр (Рим, Флоренция)", "europe/italy/centro", 384),
            ("italy-sud", "Юг (Неаполь, Бари)", "europe/italy/sud", 416),
            ("italy-isole", "Сицилия и Сардиния", "europe/italy/isole", 214),
        ],
    ),
    "spain": (
        "Испания",
        [
            ("alicante", "Аликанте (провинция)", "europe/spain/valencia", 139,
             [-1.25, 37.8, -0.05, 38.95], 300),
            ("spain-valencia", "Валенсийское сообщество", "europe/spain/valencia", 139),
            ("spain-andalucia", "Андалусия", "europe/spain/andalucia", 194),
            ("spain-aragon", "Арагон", "europe/spain/aragon", 93),
            ("spain-asturias", "Астурия", "europe/spain/asturias", 36),
            ("spain-islas-baleares", "Балеарские острова", "europe/spain/islas-baleares", 47),
            ("spain-pais-vasco", "Страна Басков", "europe/spain/pais-vasco", 68),
            ("spain-canarias", "Канарские острова", "africa/canary-islands", 40),
            ("spain-cantabria", "Кантабрия", "europe/spain/cantabria", 36),
            ("spain-castilla-la-mancha", "Кастилия — Ла-Манча", "europe/spain/castilla-la-mancha", 107),
            ("spain-castilla-y-leon", "Кастилия и Леон", "europe/spain/castilla-y-leon", 177),
            ("spain-cataluna", "Каталония", "europe/spain/cataluna", 271),
            ("spain-extremadura", "Эстремадура", "europe/spain/extremadura", 40),
            ("spain-galicia", "Галисия", "europe/spain/galicia", 111),
            ("spain-la-rioja", "Риоха", "europe/spain/la-rioja", 13),
            ("spain-madrid", "Мадрид", "europe/spain/madrid", 85),
            ("spain-murcia", "Мурсия", "europe/spain/murcia", 35),
            ("spain-navarra", "Наварра", "europe/spain/navarra", 37),
        ],
    ),
    "poland": (
        "Польша",
        [
            ("poland-dolnoslaskie", "Нижнесилезское", "europe/poland/dolnoslaskie", 180),
            ("poland-kujawsko-pomorskie", "Куявско-Поморское", "europe/poland/kujawsko-pomorskie", 104),
            ("poland-lodzkie", "Лодзинское", "europe/poland/lodzkie", 131),
            ("poland-lubelskie", "Люблинское", "europe/poland/lubelskie", 138),
            ("poland-lubuskie", "Лубушское", "europe/poland/lubuskie", 62),
            ("poland-malopolskie", "Малопольское (Краков)", "europe/poland/malopolskie", 201),
            ("poland-mazowieckie", "Мазовецкое (Варшава)", "europe/poland/mazowieckie", 300),
            ("poland-opolskie", "Опольское", "europe/poland/opolskie", 53),
            ("poland-podkarpackie", "Подкарпатское", "europe/poland/podkarpackie", 153),
            ("poland-podlaskie", "Подляское", "europe/poland/podlaskie", 78),
            ("poland-pomorskie", "Поморское (Гданьск)", "europe/poland/pomorskie", 117),
            ("poland-slaskie", "Силезское", "europe/poland/slaskie", 185),
            ("poland-swietokrzyskie", "Свентокшиское", "europe/poland/swietokrzyskie", 87),
            ("poland-warminsko-mazurskie", "Варминско-Мазурское", "europe/poland/warminsko-mazurskie", 85),
            ("poland-wielkopolskie", "Великопольское (Познань)", "europe/poland/wielkopolskie", 158),
            ("poland-zachodniopomorskie", "Западно-Поморское", "europe/poland/zachodniopomorskie", 98),
        ],
    ),
    "united-kingdom": (
        "Великобритания",
        [
            ("uk-scotland", "Шотландия", "europe/united-kingdom/scotland", 326),
            ("uk-wales", "Уэльс", "europe/united-kingdom/wales", 100),
            ("uk-england-north", "Англия: север (Манчестер, Лидс)", "europe/united-kingdom/england", 1718,
             [-3.75, 53.3, 0.35, 55.95], 0.35),
            ("uk-england-center", "Англия: центр (Бирмингем)", "europe/united-kingdom/england", 1718,
             [-3.2, 51.95, 1.85, 53.3], 0.2),
            ("uk-england-southwest", "Англия: юго-запад (Бристоль)", "europe/united-kingdom/england", 1718,
             [-6.6, 49.8, -1.4, 51.95], 0.15),
            ("uk-england-southeast", "Англия: юго-восток и Лондон", "europe/united-kingdom/england", 1718,
             [-1.4, 49.8, 1.85, 51.95], 0.3),
        ],
    ),
    "russia": (
        "Россия (европейская часть)",
        [
            ("russia-central", "Центральный округ (Москва)", "russia/central-fed-district", 879),
            ("russia-northwestern", "Северо-Западный (Санкт-Петербург)", "russia/northwestern-fed-district", 653),
            ("russia-south", "Южный округ", "russia/south-fed-district", 314),
            ("russia-north-caucasus", "Северо-Кавказский округ", "russia/north-caucasus-fed-district", 128),
            ("russia-volga", "Приволжский округ", "russia/volga-fed-district", 774),
            ("russia-kaliningrad", "Калининградская область", "russia/kaliningrad", 29),
        ],
    ),
}

RATIO = 1.3  # размер пакета / размер pbf


def est(pbf, share=1.0):
    mb = pbf * share * RATIO
    return int(max(5, round(mb, -1) if mb > 100 else round(mb)))


def entries():
    out = []
    for pid, title, gf, pbf in WHOLE:
        out.append(dict(id=pid, title=title, group=None, groupTitle=None, gf=gf, bounds=None,
                        pbf=pbf, approxMb=est(pbf)))
    for group, (gtitle, parts) in SPLIT.items():
        for p in parts:
            pid, title, gf, pbf = p[:4]
            bounds = p[4] if len(p) > 4 else None
            extra = p[5] if len(p) > 5 else None
            if isinstance(extra, int) and extra > 1:  # явный размер в МБ
                approx = extra
            else:
                approx = est(pbf, extra if isinstance(extra, float) else 1.0)
            out.append(dict(id=pid, title=title, group=group, groupTitle=gtitle, gf=gf,
                            bounds=bounds, pbf=pbf, approxMb=approx))
    return out


def dart_str(s):
    return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("$", "\\$") + "'"


def main():
    items = entries()
    ids = [e["id"] for e in items]
    assert len(ids) == len(set(ids)), "повторяющиеся id"

    (ROOT / "tool" / "packs.json").write_text(
        json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8"
    )

    lines = [
        "// СГЕНЕРИРОВАНО tool/packs_def.py. Не правьте руками: правьте tool/packs_def.py",
        "// и запустите `python3 tool/packs_def.py`.",
        "",
        "import 'pack_manager.dart';",
        "",
        "const List<PackInfo> kBuiltInPacks = [",
    ]
    for e in items:
        lines += [
            "  PackInfo(",
            f"    id: {dart_str(e['id'])},",
            f"    title: {dart_str(e['title'])},",
            f"    group: {dart_str(e['group']) if e['group'] else 'null'},",
            f"    groupTitle: {dart_str(e['groupTitle']) if e['groupTitle'] else 'null'},",
            f"    approxMb: {e['approxMb']},",
            "  ),",
        ]
    lines.append("];")
    (ROOT / "lib" / "packs" / "catalog_data.dart").write_text("\n".join(lines) + "\n", encoding="utf-8")
    total = sum(e["approxMb"] for e in items)
    print(f"пакетов: {len(items)}, всего ≈ {total / 1024:.0f} ГБ")


if __name__ == "__main__":
    main()
