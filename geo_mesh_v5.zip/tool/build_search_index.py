#!/usr/bin/env python3
"""Строит офлайн-индекс поиска (SQLite) из выгрузки OpenStreetMap (.osm.pbf).

Использование:
    python3 tool/build_search_index.py region.osm.pbf out.search.sqlite [minlon,minlat,maxlon,maxlat]

Нужен: pip install osmium
В индекс попадают: населённые пункты, места (магазины, кафе, достопримечательности...),
улицы и адреса (улица + номер дома). Поле name_norm приводится к виду без
диакритики и регистра, так же как SearchService.fold() в приложении.
"""
import sqlite3
import sys
import unicodedata

import osmium

SPECIAL = {"ł": "l", "ø": "o", "đ": "d", "ß": "ss", "ё": "е", "æ": "ae", "œ": "oe"}

PLACE_RANK = {
    "city": (100, "Город"),
    "town": (80, "Город"),
    "village": (60, "Посёлок"),
    "suburb": (50, "Район"),
    "quarter": (45, "Район"),
    "neighbourhood": (45, "Район"),
    "hamlet": (40, "Деревня"),
    "island": (35, "Остров"),
    "locality": (20, "Местность"),
}

KIND_RU = {
    "restaurant": "Ресторан", "cafe": "Кафе", "bar": "Бар", "fast_food": "Фастфуд",
    "pharmacy": "Аптека", "hospital": "Больница", "clinic": "Клиника",
    "doctors": "Врач", "dentist": "Стоматолог", "school": "Школа",
    "university": "Университет", "bank": "Банк", "atm": "Банкомат",
    "fuel": "АЗС", "parking": "Парковка", "police": "Полиция",
    "fire_station": "Пожарная часть", "post_office": "Почта",
    "supermarket": "Супермаркет", "convenience": "Магазин", "bakery": "Пекарня",
    "hotel": "Отель", "hostel": "Хостел", "museum": "Музей",
    "attraction": "Достопримечательность", "viewpoint": "Смотровая площадка",
    "beach": "Пляж", "park": "Парк", "station": "Станция",
    "aerodrome": "Аэропорт", "bus_station": "Автовокзал", "peak": "Вершина",
}

# Ключи тегов, по которым объект считается «местом».
POI_KEYS = ("amenity", "shop", "tourism", "leisure", "historic", "office")


def fold(s: str) -> str:
    s = s.lower()
    for a, b in SPECIAL.items():
        s = s.replace(a, b)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return " ".join(s.split())


class Handler(osmium.SimpleHandler):
    def __init__(self, db, bounds=None):
        super().__init__()
        self.db = db
        self.bounds = bounds
        self.batch = []
        self.seen_streets = set()
        self.count = 0

    def _flush(self):
        if self.batch:
            self.db.executemany(
                "INSERT INTO places(name,name_norm,kind,addr,lat,lon,importance) "
                "VALUES (?,?,?,?,?,?,?)",
                self.batch,
            )
            self.count += len(self.batch)
            self.batch = []

    def _put(self, name, kind, addr, lat, lon, importance):
        norm = fold(name)
        if len(norm) < 2:
            return
        if self.bounds:
            x0, y0, x1, y1 = self.bounds
            if not (x0 <= lon <= x1 and y0 <= lat <= y1):
                return
        self.batch.append((name, norm, kind, addr, round(lat, 6), round(lon, 6), importance))
        if len(self.batch) >= 20000:
            self._flush()

    def _handle(self, tags, lat, lon, is_way):
        name = tags.get("name")
        city = tags.get("addr:city") or ""

        place = tags.get("place")
        if name and place in PLACE_RANK:
            imp, kind = PLACE_RANK[place]
            self._put(name, kind, "", lat, lon, imp)
            return

        if name:
            for key in POI_KEYS:
                v = tags.get(key)
                if v:
                    self._put(name, KIND_RU.get(v, v.replace("_", " ")), city, lat, lon, 20)
                    break
            else:
                if tags.get("railway") == "station" or tags.get("aeroway") == "aerodrome":
                    v = tags.get("railway") or tags.get("aeroway")
                    self._put(name, KIND_RU.get(v, "Станция"), city, lat, lon, 30)
                elif tags.get("natural") in ("peak", "beach", "bay"):
                    v = tags["natural"]
                    self._put(name, KIND_RU.get(v, v), "", lat, lon, 25)
                elif is_way and tags.get("highway"):
                    key = (fold(name), round(lat, 2), round(lon, 2))
                    if key not in self.seen_streets:
                        self.seen_streets.add(key)
                        self._put(name, "Улица", city, lat, lon, 10)

        street = tags.get("addr:street")
        number = tags.get("addr:housenumber")
        if street and number:
            self._put(f"{street} {number}", "Адрес", city, lat, lon, 5)

    def node(self, n):
        if n.tags and n.location.valid():
            self._handle(n.tags, n.location.lat, n.location.lon, False)

    def way(self, w):
        if not w.tags:
            return
        lats = []
        lons = []
        for nd in w.nodes:
            try:
                lats.append(nd.lat)
                lons.append(nd.lon)
            except Exception:
                continue
        if lats:
            self._handle(w.tags, sum(lats) / len(lats), sum(lons) / len(lons), True)


def main():
    src, out = sys.argv[1], sys.argv[2]
    bounds = None
    if len(sys.argv) > 3 and sys.argv[3].strip():
        bounds = tuple(float(v) for v in sys.argv[3].split(','))
    db = sqlite3.connect(out)
    db.executescript(
        """
        DROP TABLE IF EXISTS places;
        CREATE TABLE places (
            name TEXT NOT NULL, name_norm TEXT NOT NULL, kind TEXT, addr TEXT,
            lat REAL NOT NULL, lon REAL NOT NULL, importance INTEGER NOT NULL
        );
        """
    )
    h = Handler(db, bounds)
    h.apply_file(src, locations=True)
    h._flush()
    db.execute("CREATE INDEX idx_places_norm ON places(name_norm)")
    db.commit()
    db.execute("VACUUM")
    db.close()
    print("записей в индексе:", h.count)


if __name__ == "__main__":
    main()
