#!/usr/bin/env python3
"""Собирает встроенную векторную карту мира world_base.mbtiles (MVT), версия 3.

Данные: Natural Earth 10m (общественное достояние). Нужен tippecanoe и shapely.

Слои (имена совпадают с lib/map/map_style.dart):
  land           суша
  countries_fill страны полигонами, с цветом mc (1..9) для раскраски
  glaciers       ледники
  lakes          озёра (мировые + европейские, подробнее)
  rivers         реки (мировые + европейские, подробнее)
  urban          городская застройка
  boundary       границы стран
  admin1         границы регионов
  roads          дороги (motorway / primary / secondary)
  rail           железные дороги
  airports       аэропорты (точки с названием)
  places         города (name_ru, население, столицы)
  regions        подписи регионов (области, провинции)
  countries      подписи стран
  marine         названия морей, заливов, проливов (name_ru)
  geo            острова, мысы, прочие объекты (name_ru)

Использование:
    python3 tool/build_world_vector.py <папка_с_geojson> <выход.mbtiles> [макс_зум=8]

Нужные файлы в папке (https://github.com/nvkelso/natural-earth-vector, папка geojson):
    ne_10m_land, ne_10m_lakes, ne_10m_lakes_europe, ne_10m_rivers_lake_centerlines,
    ne_10m_rivers_europe, ne_10m_admin_0_boundary_lines_land,
    ne_10m_admin_1_states_provinces_lines, ne_10m_admin_1_states_provinces,
    ne_10m_urban_areas, ne_10m_roads, ne_10m_railroads, ne_10m_populated_places,
    ne_10m_admin_0_countries, ne_10m_glaciated_areas, ne_10m_geography_marine_polys,
    ne_10m_geography_regions_points, ne_10m_airports   (все с расширением .geojson)
"""
import json
import os
import subprocess
import sys


def lower_props(props):
    return {k.lower(): v for k, v in (props or {}).items()}


def load(data_dir, name):
    with open(os.path.join(data_dir, name + ".geojson"), encoding="utf-8") as f:
        return json.load(f)["features"]


def write(path, feats):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"type": "FeatureCollection", "features": feats}, f, ensure_ascii=False)


def num(v, default=None):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def feat(geom, props, minzoom=None, maxzoom=None):
    out = {"type": "Feature", "geometry": geom, "properties": props}
    tc = {}
    if minzoom is not None:
        tc["minzoom"] = int(max(0, min(minzoom, 8)))
    if maxzoom is not None:
        tc["maxzoom"] = int(max(0, min(maxzoom, 8)))
    if tc:
        out["tippecanoe"] = tc
    return out


def point_of(geometry):
    """Точка внутри самого крупного полигона."""
    from shapely.geometry import shape

    geom = shape(geometry)
    if geom.geom_type == "MultiPolygon":
        geom = max(geom.geoms, key=lambda g: g.area)
    pt = geom.representative_point()
    return {"type": "Point", "coordinates": [pt.x, pt.y]}


# ---------------------------------------------------------------- слои


def layer_simple(data_dir, name, props_fn=None, minzoom_fn=None):
    out = []
    for ft in load(data_dir, name):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        props = props_fn(p) if props_fn else {}
        mz = minzoom_fn(p) if minzoom_fn else None
        out.append(feat(ft["geometry"], props, mz))
    return out


def layer_countries_fill(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_admin_0_countries"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        out.append(feat(ft["geometry"], {"mc": int(num(p.get("mapcolor9"), 1) or 1)}))
    return out


def layer_country_labels(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_admin_0_countries"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        rank = num(p.get("label_rank") or p.get("labelrank"), 5)
        out.append(
            feat(
                point_of(ft["geometry"]),
                {
                    "name": p.get("name_en") or p.get("name"),
                    "name_ru": p.get("name_ru"),
                    "rank": rank,
                },
                minzoom=max(0, min(rank - 2, 6)),
            )
        )
    return out


def layer_regions(data_dir):
    """Подписи регионов: области, провинции, земли, штаты."""
    out = []
    for ft in load(data_dir, "ne_10m_admin_1_states_provinces"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        name = p.get("name_en") or p.get("name")
        if not name:
            continue
        ml = num(p.get("min_label"), 8)
        out.append(
            feat(
                point_of(ft["geometry"]),
                {"name": name, "name_ru": p.get("name_ru"), "rank": num(p.get("labelrank"), 5)},
                minzoom=max(3, round(ml) - 2),
            )
        )
    return out


def layer_marine(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_geography_marine_polys"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        name = p.get("name_en") or p.get("name")
        if not name:
            continue
        ml = num(p.get("min_label"), 4)
        out.append(
            feat(
                point_of(ft["geometry"]),
                {
                    "name": name,
                    "name_ru": p.get("name_ru"),
                    "class": p.get("featurecla"),
                    "rank": num(p.get("scalerank"), 5),
                },
                minzoom=max(0, round(ml) - 1),
            )
        )
    return out


def layer_geo(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_geography_regions_points"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        name = p.get("name_en") or p.get("name")
        if not name:
            continue
        out.append(
            feat(
                ft["geometry"],
                {"name": name, "name_ru": p.get("name_ru"), "class": p.get("featurecla")},
                minzoom=num(p.get("min_zoom"), 4),
            )
        )
    return out


def layer_places(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_populated_places"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        rank = num(p.get("scalerank"), 8)
        mz = min(max(rank / 1.5 - 0.5, 0), 8)
        out.append(
            feat(
                ft["geometry"],
                {
                    "name": p.get("name_en") or p.get("name"),
                    "name_ru": p.get("name_ru"),
                    "rank": rank,
                    "pop": p.get("pop_max"),
                    "cap": 1 if str(p.get("featurecla", "")).startswith("Admin-0 capital") else 0,
                    "reg": 1 if "Admin-1 capital" in str(p.get("featurecla", "")) else 0,
                },
                minzoom=mz,
            )
        )
    return out


def layer_airports(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_airports"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        t = str(p.get("type") or "")
        if "military" in t and "major" not in t and "mid" not in t:
            continue
        rank = num(p.get("scalerank"), 9)
        out.append(
            feat(
                ft["geometry"],
                {
                    "name": p.get("name"),
                    "name_ru": p.get("name_ru"),
                    "iata": p.get("iata_code"),
                    "major": 1 if "major" in t else 0,
                },
                minzoom=max(5, min(8, 11 - rank)),
            )
        )
    return out


def road_props(p):
    t = p.get("type") or ""
    if p.get("expressway") == 1:
        cls = "motorway"
    elif t == "Major Highway":
        cls = "primary"
    elif t in ("Ferry Route", "Ferry, seasonal", "Track"):
        cls = "other"
    else:
        cls = "secondary"
    return {"class": cls, "type": t}


def layer_roads(data_dir):
    out = []
    for ft in load(data_dir, "ne_10m_roads"):
        if not ft.get("geometry"):
            continue
        p = lower_props(ft["properties"])
        props = road_props(p)
        if props["class"] == "other":
            continue
        base = num(p.get("min_zoom"), 6)
        # магистрали видны раньше, второстепенные позже
        mz = {"motorway": base - 1.5, "primary": base - 0.5}.get(props["class"], base + 0.5)
        out.append(feat(ft["geometry"], props, max(mz, 3)))
    return out


def main():
    data_dir, out_path = sys.argv[1], sys.argv[2]
    max_zoom = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    tmp = os.path.join(data_dir, "_prepared")
    os.makedirs(tmp, exist_ok=True)

    layers = {
        "land": layer_simple(data_dir, "ne_10m_land"),
        "countries_fill": layer_countries_fill(data_dir),
        "glaciers": layer_simple(data_dir, "ne_10m_glaciated_areas"),
        "lakes": layer_simple(data_dir, "ne_10m_lakes", lambda p: {"name": p.get("name")})
        + layer_simple(data_dir, "ne_10m_lakes_europe", lambda p: {"name": p.get("name")}),
        "rivers": layer_simple(
            data_dir,
            "ne_10m_rivers_lake_centerlines",
            lambda p: {"name": p.get("name"), "rank": num(p.get("scalerank"), 8)},
            lambda p: max(0, (num(p.get("scalerank"), 8) or 8) - 5),
        )
        + layer_simple(
            data_dir,
            "ne_10m_rivers_europe",
            lambda p: {"name": p.get("name"), "rank": num(p.get("scalerank"), 8)},
            lambda p: max(2, (num(p.get("scalerank"), 8) or 8) - 5),
        ),
        "urban": layer_simple(data_dir, "ne_10m_urban_areas"),
        "boundary": layer_simple(
            data_dir, "ne_10m_admin_0_boundary_lines_land", lambda p: {"admin": 2}
        ),
        "admin1": layer_simple(
            data_dir,
            "ne_10m_admin_1_states_provinces_lines",
            lambda p: {"admin": 4},
            lambda p: max((num(p.get("min_zoom"), 4) or 4) - 1.0, 2),
        ),
        "roads": layer_roads(data_dir),
        "rail": layer_simple(
            data_dir,
            "ne_10m_railroads",
            lambda p: {},
            lambda p: max(5, 10 - (num(p.get("scalerank"), 8) or 8) + 3),
        ),
        "airports": layer_airports(data_dir),
        "places": layer_places(data_dir),
        "regions": layer_regions(data_dir),
        "countries": layer_country_labels(data_dir),
        "marine": layer_marine(data_dir),
        "geo": layer_geo(data_dir),
    }

    args = [
        "tippecanoe",
        "-o",
        out_path,
        "--force",
        "-Z0",
        f"-z{max_zoom}",
        "--no-tile-size-limit",
        "--no-feature-limit",
        "--simplification=2",
        "--name=World base",
        "--description=Natural Earth 10m",
        "--attribution=Natural Earth",
    ]
    for name, feats in layers.items():
        dst = os.path.join(tmp, name + ".geojson")
        write(dst, feats)
        args += ["-L", f"{name}:{dst}"]
        print(f"{name}: {len(feats)}")
    subprocess.run(args, check=True)
    print("размер, МБ:", round(os.path.getsize(out_path) / 1e6, 2))


if __name__ == "__main__":
    main()
