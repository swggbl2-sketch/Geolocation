#!/usr/bin/env python3
"""Собирает спутниковый обзор ВСЕГО мира в world_sat.mbtiles (jpg, схема TMS).

Источник: Sentinel-2 cloudless © EOX (CC BY-NC-SA 4.0, только некоммерческое
использование). Готовый файл кладут в assets/maps/world_sat.mbtiles — тогда
приложение берёт его как встроенный спутник мира (тема «Спутник»).

    python3 tool/build_world_satellite.py world_sat.mbtiles [макс_зум=6] [потоков=8]

Размер сильно зависит от зума (оценки, реальный размер смотрите после сборки):
    z6  (≈2.4 км/пикс, видны леса, поля, крупные города)   ≈ 50–80 МБ
    z7  (≈1.2 км/пикс)                                      ≈ 200–300 МБ
    z8  (≈600 м/пикс)                                       ≈ 0.8–1.2 ГБ
    z9  (≈300 м/пикс)                                       ≈ 3–5 ГБ
Дома и деревья отдельно появляются примерно с z15–z17: весь мир на таком
зуме — десятки терабайт, встроить его в приложение нельзя. Для таких деталей
используйте скачивание области (кнопка со спутником) и онлайн-слой Esri.

Скрипт можно прерывать и запускать снова: уже скачанные тайлы пропускаются.
"""
import os
import sqlite3
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

URL = os.environ.get(
    "SAT_URL",
    "https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2021_3857/default/g/{z}/{y}/{x}.jpg",
)
UA = "geo_mesh-world-sat-builder/1.0 (non-commercial)"


def fetch(z, x, y, retries=4):
    url = URL.format(z=z, x=x, y=y)
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            if len(data) > 3 and data[:2] == b"\xff\xd8":
                return data
            return None
        except Exception:
            time.sleep(1.5 * (attempt + 1))
    return None


def main():
    out = sys.argv[1]
    max_zoom = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 8

    db = sqlite3.connect(out, check_same_thread=False)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS metadata (name TEXT, value TEXT);
        CREATE TABLE IF NOT EXISTS tiles (zoom_level INTEGER, tile_column INTEGER,
                                          tile_row INTEGER, tile_data BLOB);
        CREATE UNIQUE INDEX IF NOT EXISTS tile_index
            ON tiles (zoom_level, tile_column, tile_row);
        """
    )
    have = set(db.execute("SELECT zoom_level, tile_column, tile_row FROM tiles"))
    lock = threading.Lock()
    total = sum(4 ** z for z in range(max_zoom + 1))
    done = [len(have)]
    failed = []

    def work(job):
        z, x, y = job
        tms_y = (1 << z) - 1 - y
        data = fetch(z, x, y)
        with lock:
            if data is None:
                failed.append(job)
            else:
                db.execute(
                    "INSERT OR REPLACE INTO tiles VALUES (?,?,?,?)", (z, x, tms_y, data)
                )
            done[0] += 1
            if done[0] % 200 == 0:
                db.commit()
                print(f"{done[0]}/{total}", flush=True)

    jobs = [
        (z, x, y)
        for z in range(max_zoom + 1)
        for x in range(1 << z)
        for y in range(1 << z)
        if (z, x, (1 << z) - 1 - y) not in have
    ]
    with ThreadPoolExecutor(workers) as ex:
        list(ex.map(work, jobs))
    db.commit()

    db.execute("DELETE FROM metadata")
    meta = {
        "name": "World satellite overview",
        "format": "jpg",
        "type": "baselayer",
        "version": "1",
        "description": "Sentinel-2 cloudless (EOX), CC BY-NC-SA 4.0",
        "minzoom": "0",
        "maxzoom": str(max_zoom),
        "bounds": "-180,-85.0511,180,85.0511",
    }
    db.executemany("INSERT INTO metadata VALUES (?,?)", meta.items())
    db.commit()
    if failed:
        print(f"не скачано тайлов: {len(failed)} — запустите скрипт ещё раз")
        sys.exit(1)
    db.execute("VACUUM")
    db.close()
    print("размер, МБ:", round(os.path.getsize(out) / 1e6, 1))


if __name__ == "__main__":
    main()
