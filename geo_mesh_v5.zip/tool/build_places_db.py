#!/usr/bin/env python3
"""Строит встроенный справочник мест мира (SQLite) из Natural Earth populated places.

Использование:
    python3 tool/build_places_db.py ne_10m_populated_places.geojson assets/maps/places.sqlite

Формат таблицы совпадает с индексом пакетов (tool/build_search_index.py),
поэтому приложение ищет в них одним запросом.
"""
import json
import math
import sqlite3
import sys
import unicodedata

SPECIAL = {"ł": "l", "ø": "o", "đ": "d", "ß": "ss", "ё": "е", "æ": "ae", "œ": "oe"}


def fold(s: str) -> str:
    s = s.lower()
    for a, b in SPECIAL.items():
        s = s.replace(a, b)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return " ".join(s.split())


def main():
    src, out = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as f:
        feats = json.load(f)["features"]

    db = sqlite3.connect(out)
    db.executescript(
        """
        DROP TABLE IF EXISTS places;
        CREATE TABLE places (
            name TEXT NOT NULL, name_norm TEXT NOT NULL, kind TEXT, addr TEXT,
            lat REAL NOT NULL, lon REAL NOT NULL, importance INTEGER NOT NULL
        );
        """
    )
    rows = []
    for ft in feats:
        p = ft["properties"]
        lat, lon = p.get("LATITUDE"), p.get("LONGITUDE")
        if lat is None or lon is None:
            continue
        pop = max(int(p.get("POP_MAX") or 0), 0)
        imp = int(math.log10(pop + 10) * 10)  # 10..80
        cla = (p.get("FEATURECLA") or "").lower()
        if "capital" in cla:
            imp += 20
            kind = "Столица"
        else:
            kind = "Город"
        addr = ", ".join(x for x in (p.get("ADM1NAME"), p.get("ADM0NAME")) if x)

        seen = set()
        for key in ("NAME", "NAME_RU", "NAME_EN", "NAME_ES"):
            name = p.get(key)
            if not name:
                continue
            norm = fold(name)
            if norm in seen or len(norm) < 2:
                continue
            seen.add(norm)
            rows.append((name, norm, kind, addr, round(lat, 5), round(lon, 5), imp))

    db.executemany("INSERT INTO places VALUES (?,?,?,?,?,?,?)", rows)
    db.execute("CREATE INDEX idx_places_norm ON places(name_norm)")
    db.commit()
    db.execute("VACUUM")
    db.close()
    print("записей:", len(rows))


if __name__ == "__main__":
    main()
