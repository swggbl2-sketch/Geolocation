#!/usr/bin/env python3
"""Собирает один пакет каталога: <id>.mbtiles (+ части, если больше 1,9 ГБ) и <id>.search.sqlite.

    python3 tool/build_pack.py <id> <папка_вывода>

Нужны: java 21, planetiler.jar в текущей папке, pip install osmium.
Читает tool/packs.json (его генерирует tool/packs_def.py).
"""
import json
import pathlib
import subprocess
import sys
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
PART = 1900 * 1024 * 1024


def run(cmd):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, check=True)


def main():
    pid, out = sys.argv[1], pathlib.Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    item = next(e for e in json.loads((ROOT / "tool/packs.json").read_text("utf-8")) if e["id"] == pid)
    bounds = ",".join(str(x) for x in item["bounds"]) if item["bounds"] else None

    pbf = out / f"{pid}.osm.pbf"
    url = f"https://download.geofabrik.de/{item['gf']}-latest.osm.pbf"
    print("скачиваю", url, flush=True)
    urllib.request.urlretrieve(url, pbf)

    mb = out / f"{pid}.mbtiles"
    cmd = [
        "java", "-Xmx9g", "-jar", "planetiler.jar",
        f"--osm-path={pbf}", f"--output={mb}", "--force", "--download",
        "--maxzoom=14", "--nodemap-type=sparsearray", "--storage=mmap",
        f"--tmpdir={out / 'tmp'}",
    ]
    if bounds:
        cmd.append(f"--bounds={bounds}")
    run(cmd)

    search = out / f"{pid}.search.sqlite"
    cmd = [sys.executable, str(ROOT / "tool/build_search_index.py"), str(pbf), str(search)]
    if bounds:
        cmd.append(bounds)
    run(cmd)
    pbf.unlink()

    size = mb.stat().st_size
    if size > PART:
        names = []
        with mb.open("rb") as f:
            i = 0
            while True:
                chunk = f.read(PART)
                if not chunk:
                    break
                name = f"{pid}.mbtiles.p{i:03d}"
                (out / name).write_bytes(chunk)
                names.append({"name": name, "size": len(chunk)})
                i += 1
        mb.unlink()
    else:
        names = [{"name": mb.name, "size": size}]
    (out / f"{pid}.parts.json").write_text(json.dumps({"parts": names}), encoding="utf-8")
    print("готово:", names, flush=True)


if __name__ == "__main__":
    main()
