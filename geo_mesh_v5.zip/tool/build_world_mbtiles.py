#!/usr/bin/env python3
"""Собирает обзорную карту мира (суша, озёра, границы стран) в world.mbtiles.

Данные: Natural Earth 1:50m (общественное достояние).
Использование:
    python3 tool/build_world_mbtiles.py <папка_с_geojson> <выход.mbtiles> [макс_зум=6]
Нужны: numpy, pillow.
"""
import io
import json
import os
import sqlite3
import sys

import numpy as np
from PIL import Image, ImageDraw

OCEAN = (181, 215, 235)
LAND = (243, 240, 232)
COAST = (122, 150, 175)
BORDER = (160, 150, 165)
MAXLAT = 85.0511287798
SS = 2  # суперсэмплинг для сглаживания


def load(data_dir, name):
    with open(os.path.join(data_dir, name + ".geojson"), encoding="utf-8") as f:
        return json.load(f)["features"]


def polygons(features):
    for ft in features:
        g = ft["geometry"]
        if not g:
            continue
        if g["type"] == "Polygon":
            yield g["coordinates"]
        elif g["type"] == "MultiPolygon":
            yield from g["coordinates"]


def lines(features):
    for ft in features:
        g = ft["geometry"]
        if not g:
            continue
        if g["type"] == "LineString":
            yield g["coordinates"]
        elif g["type"] == "MultiLineString":
            yield from g["coordinates"]


def project(coords, z):
    a = np.asarray(coords, dtype=float)[:, :2]
    lon = a[:, 0]
    lat = np.clip(a[:, 1], -MAXLAT, MAXLAT)
    n = 256 * 2 ** z
    x = (lon + 180.0) / 360.0 * n
    s = np.sin(np.radians(lat))
    y = (0.5 - np.log((1 + s) / (1 - s)) / (4 * np.pi)) * n
    return np.column_stack([x, y])


class Layer:
    """Набор колец, спроецированных на зум, с bbox для быстрой фильтрации."""

    def __init__(self, rings, z):
        self.rings = []
        boxes = []
        for r in rings:
            if len(r) < 2:
                continue
            p = project(r, z)
            mn, mx = p.min(axis=0), p.max(axis=0)
            if (mx - mn).max() < 0.4:  # меньше полпикселя: не рисуем
                continue
            self.rings.append(p)
            boxes.append([mn[0], mn[1], mx[0], mx[1]])
        self.boxes = np.array(boxes) if boxes else np.zeros((0, 4))

    def visible(self, x0, y0):
        b = self.boxes
        if not len(b):
            return []
        m = (b[:, 2] >= x0 - 2) & (b[:, 0] <= x0 + 258) & (b[:, 3] >= y0 - 2) & (b[:, 1] <= y0 + 258)
        return [self.rings[i] for i in np.nonzero(m)[0]]


def flat(p, x0, y0):
    q = (p - (x0, y0)) * SS
    return q.ravel().tolist()


def main():
    data_dir, out_path = sys.argv[1], sys.argv[2]
    max_zoom = int(sys.argv[3]) if len(sys.argv) > 3 else 6

    land_polys = list(polygons(load(data_dir, "ne_50m_land")))
    lake_polys = list(polygons(load(data_dir, "ne_50m_lakes")))
    border_lines = list(lines(load(data_dir, "ne_50m_admin_0_boundary_lines_land")))

    if os.path.exists(out_path):
        os.remove(out_path)
    db = sqlite3.connect(out_path)
    db.executescript(
        """
        CREATE TABLE metadata (name TEXT, value TEXT);
        CREATE TABLE tiles (zoom_level INTEGER, tile_column INTEGER,
                            tile_row INTEGER, tile_data BLOB);
        CREATE UNIQUE INDEX tile_index ON tiles (zoom_level, tile_column, tile_row);
        """
    )
    meta = {
        "name": "World overview",
        "format": "png",
        "type": "baselayer",
        "version": "1",
        "description": "Natural Earth 1:50m: land, lakes, country borders",
        "minzoom": "0",
        "maxzoom": str(max_zoom),
        "bounds": f"-180,{-MAXLAT},180,{MAXLAT}",
        "center": "0,20,2",
    }
    db.executemany("INSERT INTO metadata VALUES (?,?)", meta.items())

    total = 0
    for z in range(max_zoom + 1):
        # exteriors / holes отдельно: сначала суша, потом дыры (Каспий и т.п.)
        ext = Layer([poly[0] for poly in land_polys], z)
        holes = Layer([r for poly in land_polys for r in poly[1:]], z)
        lakes = Layer([poly[0] for poly in lake_polys], z)
        borders = Layer(border_lines, z)
        n = 2 ** z
        for ty in range(n):
            for tx in range(n):
                x0, y0 = tx * 256, ty * 256
                img = Image.new("RGB", (256 * SS, 256 * SS), OCEAN)
                d = ImageDraw.Draw(img)
                for p in ext.visible(x0, y0):
                    if len(p) >= 3:
                        d.polygon(flat(p, x0, y0), fill=LAND)
                for p in holes.visible(x0, y0):
                    if len(p) >= 3:
                        d.polygon(flat(p, x0, y0), fill=OCEAN)
                for p in lakes.visible(x0, y0):
                    if len(p) >= 3:
                        d.polygon(flat(p, x0, y0), fill=OCEAN)
                if z >= 2:
                    for p in borders.visible(x0, y0):
                        d.line(flat(p, x0, y0), fill=BORDER, width=SS)
                for p in ext.visible(x0, y0):
                    d.line(flat(p, x0, y0), fill=COAST, width=SS)
                tile = img.resize((256, 256), Image.LANCZOS).quantize(colors=24)
                buf = io.BytesIO()
                tile.save(buf, format="PNG", optimize=True)
                db.execute(
                    "INSERT INTO tiles VALUES (?,?,?,?)",
                    (z, tx, n - 1 - ty, buf.getvalue()),  # TMS: ось Y перевёрнута
                )
                total += 1
        db.commit()
        print(f"zoom {z} готов, всего тайлов: {total}", flush=True)

    db.execute("VACUUM")
    db.close()
    print("размер, МБ:", round(os.path.getsize(out_path) / 1e6, 2))


if __name__ == "__main__":
    main()
