import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';

import 'package:geo_mesh/geo/geohash.dart';
import 'package:geo_mesh/mesh/geo_message.dart';
import 'package:geo_mesh/packs/satellite_downloader.dart';
import 'package:geo_mesh/search/coord_parser.dart';
import 'package:geo_mesh/search/search_service.dart';

void main() {
  group('Geohash', () {
    test('известные эталонные значения', () {
      expect(Geohash.encode(57.64911, 10.40744, precision: 11), 'u4pruydqqvj');
      final c = Geohash.decode('ezs42');
      expect(c.latitude, closeTo(42.605, 1e-3));
      expect(c.longitude, closeTo(-5.603, 1e-3));
    });

    test('круговое преобразование в Аликанте укладывается в погрешность', () {
      const lat = 38.34517, lon = -0.48149;
      for (final precision in [8, 9, 10]) {
        final cell = Geohash.decodeCell(Geohash.encode(lat, lon, precision: precision));
        final d = const Distance().as(LengthUnit.Meter, LatLng(lat, lon), cell.center);
        expect(d, lessThanOrEqualTo(cell.errorMeters * 1.5));
      }
    });

    test('9 символов — около 5 м', () {
      final cell = Geohash.decodeCell(Geohash.encode(38.3452, -0.4810, precision: 9));
      expect(cell.errorMeters, lessThan(5));
    });

    test('невалидные входные данные', () {
      expect(Geohash.isValid('abc'), isFalse); // "a" нет в алфавите
      expect(() => Geohash.decode('a!'), throwsFormatException);
      expect(() => Geohash.encode(91, 0), throwsRangeError);
    });
  });

  group('GeoMessage', () {
    test('build -> tryParse', () {
      final text = GeoMessage.build(38.3452, -0.4810);
      expect(text.startsWith('GEO:'), isTrue);
      final parsed = GeoMessage.tryParse(text)!;
      expect(parsed.position.latitude, closeTo(38.3452, 1e-4));
      expect(parsed.position.longitude, closeTo(-0.4810, 1e-4));
    });

    test('чужие и битые сообщения -> null', () {
      expect(GeoMessage.tryParse('привет'), isNull);
      expect(GeoMessage.tryParse('GEO:'), isNull);
      expect(GeoMessage.tryParse('GEO:!!!'), isNull);
    });
  });

  group('SearchService.fold', () {
    test('диакритика и регистр', () {
      expect(SearchService.fold('Café Ñandú'), 'cafe nandu');
      expect(SearchService.fold('  Calle   MAYOR '), 'calle mayor');
      expect(SearchService.fold('Ёлка'), 'елка');
    });
  });

  group('CoordParser', () {
    test('десятичные', () {
      expect(CoordParser.parse('38.3452, -0.481')!.latitude, closeTo(38.3452, 1e-6));
      expect(CoordParser.parse('38,3452 -0,481')!.longitude, closeTo(-0.481, 1e-6));
    });
    test('стороны света и градусы', () {
      final a = CoordParser.parse('38°20\'42.7"N 0°28\'51.6"W')!;
      expect(a.latitude, closeTo(38.3452, 1e-3));
      expect(a.longitude, closeTo(-0.481, 1e-3));
      final b = CoordParser.parse('38.3452 N 0.481 W')!;
      expect(b.longitude, closeTo(-0.481, 1e-6));
    });
    test('геохеш и мусор', () {
      final g = CoordParser.parse('GEO:eyz80euzn')!;
      expect(g.latitude, closeTo(38.34, 0.05));
      expect(CoordParser.parse('Calle 12'), isNull);
      expect(CoordParser.parse('2026'), isNull);
    });
  });

  group('SatelliteDownloader', () {
    SatelliteJob job(int minZ, int maxZ, {double w = -180, double s = -85, double e = 180, double n = 85}) =>
        SatelliteJob(
          id: 't', title: 't', provider: SatProvider.eox,
          west: w, south: s, east: e, north: n, minZoom: minZ, maxZoom: maxZ,
        );

    test('число тайлов', () {
      expect(SatelliteDownloader.countTiles(job(0, 0)), 1);
      expect(SatelliteDownloader.countTiles(job(0, 1)), 5);
      expect(SatelliteDownloader.countTiles(job(3, 3)), 64);
    });

    test('Европа до z11 в пределах лимита', () {
      final eu = SatRegion.presets.first;
      final j = job(3, 11, w: eu.west, s: eu.south, e: eu.east, n: eu.north);
      expect(SatelliteDownloader.countTiles(j), lessThan(SatelliteDownloader.maxTiles));
    });

    test('задание сериализуется', () {
      final j = job(3, 9);
      final back = SatelliteJob.fromJson(j.toJson());
      expect(back.provider, SatProvider.eox);
      expect(back.maxZoom, 9);
    });
  });
}
